import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User tiers
export type UserTier = "free" | "standard" | "student";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  tier: text("tier").notNull().default("free"),
  minutesRemaining: integer("minutes_remaining").notNull().default(30),
  emailVerified: boolean("email_verified").notNull().default(false),
  studentEmailDomainValid: boolean("student_email_domain_valid").default(false),
  verificationCode: text("verification_code"),
  verificationCodeExpiry: timestamp("verification_code_expiry"),
  stripeCustomerId: text("stripe_customer_id"),
  totalPurchases: integer("total_purchases").notNull().default(0),
  isAdmin: boolean("is_admin").notNull().default(false),
  isSuspended: boolean("is_suspended").notNull().default(false),
  suspendedReason: text("suspended_reason"),
  suspendedAt: timestamp("suspended_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  name: true,
  tier: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Videos table
export const videos = pgTable("videos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  url: text("url").notNull(),
  title: text("title").notNull(),
  duration: integer("duration").notNull(), // in seconds
  platform: text("platform").notNull(), // youtube, vimeo, dailymotion
  thumbnailUrl: text("thumbnail_url"),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVideoSchema = createInsertSchema(videos).pick({
  userId: true,
  url: true,
  title: true,
  duration: true,
  platform: true,
  thumbnailUrl: true,
});

export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Video = typeof videos.$inferSelect;

// Subtitles table
export const subtitles = pgTable("subtitles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoId: varchar("video_id").notNull(),
  language: text("language").notNull(),
  content: text("content").notNull(), // Smart Sync JSON
  srtContent: text("srt_content"),
  vttContent: text("vtt_content"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSubtitleSchema = createInsertSchema(subtitles).pick({
  videoId: true,
  language: true,
  content: true,
});

export type InsertSubtitle = z.infer<typeof insertSubtitleSchema>;
export type Subtitle = typeof subtitles.$inferSelect;

// Subtitle settings table
export const subtitleSettings = pgTable("subtitle_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  fontSize: integer("font_size").notNull().default(18),
  fontColor: text("font_color").notNull().default("#ffffff"),
  backgroundColor: text("background_color").notNull().default("rgba(0,0,0,0.7)"),
  fontFamily: text("font_family").notNull().default("Outfit"),
  position: text("position").notNull().default("bottom"),
});

export const insertSubtitleSettingsSchema = createInsertSchema(subtitleSettings).pick({
  userId: true,
  fontSize: true,
  fontColor: true,
  backgroundColor: true,
  fontFamily: true,
  position: true,
});

export type InsertSubtitleSettings = z.infer<typeof insertSubtitleSettingsSchema>;
export type SubtitleSettings = typeof subtitleSettings.$inferSelect;

// API Costs settings
export const settingsApiCosts = pgTable("settings_api_costs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gpt4oTranscribeCost: real("gpt4o_transcribe_cost").notNull().default(0.0062),
  gpt4oMiniCost: real("gpt4o_mini_cost").notNull().default(0.00053),
  profitMargin: real("profit_margin").notNull().default(0.26),
  vatPercentage: real("vat_percentage").notNull().default(0),
  taxPercentage: real("tax_percentage").notNull().default(0),
  studentDiscount: real("student_discount").notNull().default(0.17),
});

export type SettingsApiCosts = typeof settingsApiCosts.$inferSelect;

// Shared video links
export const sharedVideoLinks = pgTable("shared_video_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoId: varchar("video_id").notNull(),
  userId: varchar("user_id").notNull(),
  shareCode: text("share_code").notNull().unique(),
  password: text("password"),
  isPasswordProtected: boolean("is_password_protected").notNull().default(false),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type SharedVideoLink = typeof sharedVideoLinks.$inferSelect;

// Video history
export const videoHistory = pgTable("video_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  videoId: varchar("video_id").notNull(),
  language: text("language").notNull(),
  watchedAt: timestamp("watched_at").defaultNow(),
});

export type VideoHistory = typeof videoHistory.$inferSelect;

// Pricing calculation request/response types
export interface PricingRequest {
  minutes: number;
  tier: UserTier;
}

export interface PricingResponse {
  minutes: number;
  apiCost: number;
  profit: number;
  vat: number;
  tax: number;
  discount: number;
  finalPrice: number;
  pricePerMinute: number;
}

// Smart Sync subtitle entry
export interface SmartSyncEntry {
  id: string;
  startTime: number;
  endTime: number;
  text: string;
}

// Registration request
export interface RegisterRequest {
  email: string;
  password: string;
  name: string;
  tier: UserTier;
}

// Login request
export interface LoginRequest {
  email: string;
  password: string;
}

// Verification request
export interface VerifyEmailRequest {
  email: string;
  code: string;
}

// Video processing request
export interface ProcessVideoRequest {
  url: string;
  targetLanguage: string;
}

// Discount codes table
export const discountCodes = pgTable("discount_codes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: text("code").notNull().unique(),
  discountType: text("discount_type").notNull().default("percentage"),
  discountValue: integer("discount_value").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  createdBy: varchar("created_by"),
  usageCount: integer("usage_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDiscountCodeSchema = createInsertSchema(discountCodes).pick({
  code: true,
  discountValue: true,
  startDate: true,
  endDate: true,
  createdBy: true,
});

export type InsertDiscountCode = z.infer<typeof insertDiscountCodeSchema>;
export type DiscountCode = typeof discountCodes.$inferSelect;

// Payments table for idempotent webhook processing
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stripeSessionId: text("stripe_session_id").notNull().unique(),
  userId: varchar("user_id").notNull(),
  amount: integer("amount").notNull(),
  minutes: integer("minutes").notNull(),
  status: text("status").notNull().default("completed"),
  processedAt: timestamp("processed_at").defaultNow(),
});

export type Payment = typeof payments.$inferSelect;

// Ads configuration table
export const adsConfig = pgTable("ads_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  providerName: text("provider_name").notNull(), // e.g., "Google AdSense"
  adCode: text("ad_code").notNull(), // HTML/JS snippet
  placement: text("placement").notNull(), // "free_tier", "shared_links", "both"
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertAdsConfigSchema = createInsertSchema(adsConfig).pick({
  providerName: true,
  adCode: true,
  placement: true,
  enabled: true,
});

export type InsertAdsConfig = z.infer<typeof insertAdsConfigSchema>;
export type AdsConfig = typeof adsConfig.$inferSelect;

// Admin logs table for audit tracking
export const adminLogs = pgTable("admin_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  adminId: varchar("admin_id").notNull(),
  action: text("action").notNull(), // e.g., "update_pricing", "create_discount", "delete_user"
  targetType: text("target_type"), // e.g., "user", "discount_code", "settings"
  targetId: varchar("target_id"),
  details: text("details"), // JSON string with additional info
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type AdminLog = typeof adminLogs.$inferSelect;

// Invoice records for fiscal tracking
export const invoiceRecords = pgTable("invoice_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  paymentId: varchar("payment_id").notNull(),
  amount: real("amount").notNull(), // Total amount in EUR
  minutes: integer("minutes").notNull(),
  apiCost: real("api_cost").notNull(),
  profit: real("profit").notNull(),
  vatAmount: real("vat_amount").notNull().default(0),
  taxAmount: real("tax_amount").notNull().default(0),
  discountAmount: real("discount_amount").notNull().default(0),
  discountCodeId: varchar("discount_code_id"),
  tier: text("tier").notNull(), // "standard" or "student"
  fiscalYearId: varchar("fiscal_year_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type InvoiceRecord = typeof invoiceRecords.$inferSelect;

// Fiscal years table for Tax/VAT tracking
export const fiscalYears = pgTable("fiscal_years", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  yearNumber: integer("year_number").notNull(), // 1, 2, 3...
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  totalPayments: real("total_payments").notNull().default(0), // Total in EUR
  totalTax: real("total_tax").notNull().default(0), // 10% always
  totalVat: real("total_vat").notNull().default(0), // 18% only if >30,000
  vatActive: boolean("vat_active").notNull().default(false), // Activated when threshold reached
  isPaid: boolean("is_paid").notNull().default(false),
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type FiscalYear = typeof fiscalYears.$inferSelect;

// Discount code usage log for audit
export const discountCodeUsage = pgTable("discount_code_usage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  discountCodeId: varchar("discount_code_id").notNull(),
  userId: varchar("user_id").notNull(),
  paymentId: varchar("payment_id").notNull(),
  discountValue: integer("discount_value").notNull(),
  tier: text("tier").notNull(),
  usedAt: timestamp("used_at").defaultNow(),
});

export type DiscountCodeUsage = typeof discountCodeUsage.$inferSelect;

// Supported languages (200+ as per specification)
export const supportedLanguages = [
  { code: "en", name: "English" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "it", name: "Italian" },
  { code: "pt", name: "Portuguese" },
  { code: "ru", name: "Russian" },
  { code: "zh", name: "Chinese (Simplified)" },
  { code: "zh-TW", name: "Chinese (Traditional)" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "ar", name: "Arabic" },
  { code: "hi", name: "Hindi" },
  { code: "nl", name: "Dutch" },
  { code: "pl", name: "Polish" },
  { code: "tr", name: "Turkish" },
  { code: "vi", name: "Vietnamese" },
  { code: "th", name: "Thai" },
  { code: "sv", name: "Swedish" },
  { code: "da", name: "Danish" },
  { code: "fi", name: "Finnish" },
  { code: "no", name: "Norwegian" },
  { code: "cs", name: "Czech" },
  { code: "sk", name: "Slovak" },
  { code: "hu", name: "Hungarian" },
  { code: "ro", name: "Romanian" },
  { code: "bg", name: "Bulgarian" },
  { code: "uk", name: "Ukrainian" },
  { code: "el", name: "Greek" },
  { code: "he", name: "Hebrew" },
  { code: "id", name: "Indonesian" },
  { code: "ms", name: "Malay" },
  { code: "tl", name: "Tagalog" },
  { code: "sw", name: "Swahili" },
  { code: "af", name: "Afrikaans" },
  { code: "sq", name: "Albanian" },
  { code: "am", name: "Amharic" },
  { code: "hy", name: "Armenian" },
  { code: "az", name: "Azerbaijani" },
  { code: "eu", name: "Basque" },
  { code: "be", name: "Belarusian" },
  { code: "bn", name: "Bengali" },
  { code: "bs", name: "Bosnian" },
  { code: "ca", name: "Catalan" },
  { code: "ceb", name: "Cebuano" },
  { code: "ny", name: "Chichewa" },
  { code: "co", name: "Corsican" },
  { code: "hr", name: "Croatian" },
  { code: "eo", name: "Esperanto" },
  { code: "et", name: "Estonian" },
  { code: "fj", name: "Fijian" },
  { code: "fy", name: "Frisian" },
  { code: "gl", name: "Galician" },
  { code: "ka", name: "Georgian" },
  { code: "gu", name: "Gujarati" },
  { code: "ht", name: "Haitian Creole" },
  { code: "ha", name: "Hausa" },
  { code: "haw", name: "Hawaiian" },
  { code: "hmn", name: "Hmong" },
  { code: "is", name: "Icelandic" },
  { code: "ig", name: "Igbo" },
  { code: "ga", name: "Irish" },
  { code: "jw", name: "Javanese" },
  { code: "kn", name: "Kannada" },
  { code: "kk", name: "Kazakh" },
  { code: "km", name: "Khmer" },
  { code: "rw", name: "Kinyarwanda" },
  { code: "ku", name: "Kurdish" },
  { code: "ky", name: "Kyrgyz" },
  { code: "lo", name: "Lao" },
  { code: "la", name: "Latin" },
  { code: "lv", name: "Latvian" },
  { code: "lt", name: "Lithuanian" },
  { code: "lb", name: "Luxembourgish" },
  { code: "mk", name: "Macedonian" },
  { code: "mg", name: "Malagasy" },
  { code: "ml", name: "Malayalam" },
  { code: "mt", name: "Maltese" },
  { code: "mi", name: "Maori" },
  { code: "mr", name: "Marathi" },
  { code: "mn", name: "Mongolian" },
  { code: "my", name: "Myanmar (Burmese)" },
  { code: "ne", name: "Nepali" },
  { code: "or", name: "Odia (Oriya)" },
  { code: "ps", name: "Pashto" },
  { code: "fa", name: "Persian" },
  { code: "pa", name: "Punjabi" },
  { code: "sm", name: "Samoan" },
  { code: "gd", name: "Scots Gaelic" },
  { code: "sr", name: "Serbian" },
  { code: "st", name: "Sesotho" },
  { code: "sn", name: "Shona" },
  { code: "sd", name: "Sindhi" },
  { code: "si", name: "Sinhala" },
  { code: "sl", name: "Slovenian" },
  { code: "so", name: "Somali" },
  { code: "su", name: "Sundanese" },
  { code: "tg", name: "Tajik" },
  { code: "ta", name: "Tamil" },
  { code: "tt", name: "Tatar" },
  { code: "te", name: "Telugu" },
  { code: "tk", name: "Turkmen" },
  { code: "ur", name: "Urdu" },
  { code: "ug", name: "Uyghur" },
  { code: "uz", name: "Uzbek" },
  { code: "cy", name: "Welsh" },
  { code: "xh", name: "Xhosa" },
  { code: "yi", name: "Yiddish" },
  { code: "yo", name: "Yoruba" },
  { code: "zu", name: "Zulu" },
] as const;

export type LanguageCode = typeof supportedLanguages[number]["code"];

// Analytics table for tracking platform metrics
export const analytics = pgTable("analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventType: text("event_type").notNull(), // "video_processed", "user_registered", "payment_completed", etc.
  userId: varchar("user_id"),
  videoId: varchar("video_id"),
  metadata: text("metadata"), // JSON string with additional data
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAnalyticsSchema = createInsertSchema(analytics).pick({
  eventType: true,
  userId: true,
  videoId: true,
  metadata: true,
});

export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
export type Analytics = typeof analytics.$inferSelect;

// Reports table for generated reports
export const reports = pgTable("reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // "fiscal", "usage", "revenue", etc.
  title: text("title").notNull(),
  content: text("content").notNull(), // JSON or HTML content
  generatedBy: varchar("generated_by").notNull(),
  fiscalYearId: varchar("fiscal_year_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReportSchema = createInsertSchema(reports).pick({
  type: true,
  title: true,
  content: true,
  generatedBy: true,
  fiscalYearId: true,
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;

// Compliance logs for regulatory tracking
export const complianceLogs = pgTable("compliance_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  action: text("action").notNull(), // "gdpr_request", "data_export", "data_deletion", etc.
  userId: varchar("user_id"),
  details: text("details"), // JSON with action details
  performedBy: varchar("performed_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertComplianceLogSchema = createInsertSchema(complianceLogs).pick({
  action: true,
  userId: true,
  details: true,
  performedBy: true,
});

export type InsertComplianceLog = z.infer<typeof insertComplianceLogSchema>;
export type ComplianceLog = typeof complianceLogs.$inferSelect;

// Video processing jobs for queue management
export const videoProcessingJobs = pgTable("video_processing_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoId: varchar("video_id").notNull(),
  userId: varchar("user_id").notNull(),
  status: text("status").notNull().default("queued"), // "queued", "processing", "completed", "failed"
  targetLanguage: text("target_language").notNull(),
  progress: integer("progress").notNull().default(0), // 0-100
  errorMessage: text("error_message"),
  retryCount: integer("retry_count").notNull().default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVideoProcessingJobSchema = createInsertSchema(videoProcessingJobs).pick({
  videoId: true,
  userId: true,
  targetLanguage: true,
  status: true,
  progress: true,
  errorMessage: true,
});

export type InsertVideoProcessingJob = z.infer<typeof insertVideoProcessingJobSchema>;
export type VideoProcessingJob = typeof videoProcessingJobs.$inferSelect;

// Email verifications for tracking verification attempts
export const emailVerifications = pgTable("email_verifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull(),
  code: text("code").notNull(),
  type: text("type").notNull(), // "registration", "password_reset", "email_change"
  status: text("status").notNull().default("pending"), // "pending", "verified", "expired"
  tier: text("tier"), // requested tier during registration
  studentEmailValid: boolean("student_email_valid"),
  expiresAt: timestamp("expires_at").notNull(),
  verifiedAt: timestamp("verified_at"),
  resendCount: integer("resend_count").notNull().default(0),
  lastResendAt: timestamp("last_resend_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertEmailVerificationSchema = createInsertSchema(emailVerifications).pick({
  email: true,
  code: true,
  type: true,
  tier: true,
  studentEmailValid: true,
  expiresAt: true,
});

export type InsertEmailVerification = z.infer<typeof insertEmailVerificationSchema>;
export type EmailVerification = typeof emailVerifications.$inferSelect;

// Profit settings per tier
export const profitSettings = pgTable("profit_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tier: text("tier").notNull().unique(), // "standard", "student"
  profitMargin: real("profit_margin").notNull().default(0.26), // 26% default
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProfitSettingsSchema = createInsertSchema(profitSettings).pick({
  tier: true,
  profitMargin: true,
});

export type InsertProfitSettings = z.infer<typeof insertProfitSettingsSchema>;
export type ProfitSettings = typeof profitSettings.$inferSelect;

// Tax settings per tier
export const taxSettings = pgTable("tax_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tier: text("tier").notNull().unique(), // "standard", "student"
  taxEnabled: boolean("tax_enabled").notNull().default(true),
  taxPercentage: real("tax_percentage").notNull().default(0.10), // 10% default
  vatEnabled: boolean("vat_enabled").notNull().default(false),
  vatPercentage: real("vat_percentage").notNull().default(0.18), // 18% default
  vatThreshold: real("vat_threshold").notNull().default(30000), // €30,000 threshold
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertTaxSettingsSchema = createInsertSchema(taxSettings).pick({
  tier: true,
  taxEnabled: true,
  taxPercentage: true,
  vatEnabled: true,
  vatPercentage: true,
  vatThreshold: true,
});

export type InsertTaxSettings = z.infer<typeof insertTaxSettingsSchema>;
export type TaxSettings = typeof taxSettings.$inferSelect;

// Smart Sync logs for debugging and monitoring
export const smartSyncLogs = pgTable("smart_sync_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoId: varchar("video_id").notNull(),
  subtitleId: varchar("subtitle_id"),
  processingTimeMs: integer("processing_time_ms"),
  segmentCount: integer("segment_count"),
  inputTokens: integer("input_tokens"),
  outputTokens: integer("output_tokens"),
  status: text("status").notNull(), // "success", "failed", "partial"
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSmartSyncLogSchema = createInsertSchema(smartSyncLogs).pick({
  videoId: true,
  subtitleId: true,
  processingTimeMs: true,
  segmentCount: true,
  inputTokens: true,
  outputTokens: true,
  status: true,
  errorMessage: true,
});

export type InsertSmartSyncLog = z.infer<typeof insertSmartSyncLogSchema>;
export type SmartSyncLog = typeof smartSyncLogs.$inferSelect;

// User notifications table
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"), // "info", "success", "warning", "error"
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertNotificationSchema = createInsertSchema(notifications).pick({
  userId: true,
  title: true,
  message: true,
  type: true,
});

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// Paid packages for tracking purchased minute bundles
export const paidPackages = pgTable("paid_packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  minutes: integer("minutes").notNull(),
  priceTotal: real("price_total").notNull(),
  pricePerMinute: real("price_per_minute").notNull(),
  tier: text("tier").notNull(),
  paymentId: varchar("payment_id"),
  expiresAt: timestamp("expires_at"), // null = never expires
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPaidPackageSchema = createInsertSchema(paidPackages).pick({
  userId: true,
  minutes: true,
  priceTotal: true,
  pricePerMinute: true,
  tier: true,
  paymentId: true,
  expiresAt: true,
});

export type InsertPaidPackage = z.infer<typeof insertPaidPackageSchema>;
export type PaidPackage = typeof paidPackages.$inferSelect;

// User notifications table
export const userNotifications = pgTable("user_notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"), // "info", "warning", "success", "error"
  isRead: boolean("is_read").notNull().default(false),
  sentBy: varchar("sent_by"), // admin ID
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserNotificationSchema = createInsertSchema(userNotifications).pick({
  userId: true,
  title: true,
  message: true,
  type: true,
  sentBy: true,
});

export type InsertUserNotification = z.infer<typeof insertUserNotificationSchema>;
export type UserNotification = typeof userNotifications.$inferSelect;

// Re-export chat schema for integrations
export * from "./models/chat";
