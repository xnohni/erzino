import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import type { UserTier, PricingRequest } from "@shared/schema";
import { transcribeAndTranslate, formatToSRT, formatToVTT } from "./services/ai-transcription";
import { stripeService } from "./stripe/stripeService";
import { getStripePublishableKey, getStripeSync } from "./stripe/stripeClient";
import { runMigrations } from "stripe-replit-sync";
import bcrypt from "bcryptjs";

// Max minutes per purchase (prevents abuse)
const MAX_MINUTES_PER_PURCHASE = 10000;

// Rate limiting for verification code resends (module scope for persistence)
const resendAttempts = new Map<string, { count: number; lastAttempt: Date }>();

// Validation schemas
const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(1),
  tier: z.enum(["free", "standard", "student"]),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const verifySchema = z.object({
  email: z.string().email(),
  code: z.string().length(6),
});

const pricingSchema = z.object({
  minutes: z.number().min(350).max(17000),
  tier: z.enum(["free", "standard", "student"]),
});

const processVideoSchema = z.object({
  url: z.string().url(),
  targetLanguage: z.string(),
  estimatedMinutes: z.number().positive().max(600).optional(),
});

const subtitleSettingsSchema = z.object({
  userId: z.string(),
  fontSize: z.number().min(12).max(32),
  fontColor: z.string(),
  backgroundColor: z.string(),
  fontFamily: z.string(),
  position: z.enum(["top", "bottom"]),
});

// Helper to generate 6-digit code
function generateVerificationCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Helper to check if email is academic (enhanced with comprehensive patterns)
function isAcademicEmail(email: string): boolean {
  const domain = email.split("@")[1]?.toLowerCase() || "";
  const academicPatterns = [
    /\.edu$/,
    /\.edu\./,
    /\.ac\./,
    /\.ac\.uk$/,
    /\.ac\.jp$/,
    /\.ac\.kr$/,
    /\.ac\.nz$/,
    /\.ac\.za$/,
    /\.ac\.in$/,
    /^student\./,
    /^students\./,
    /^mail\..*\.edu/,
    /^campus\./,
    /\.university\./,
    /\.uni\./,
    /\.sch\./,
    /\.edu\.au$/,
    /\.edu\.cn$/,
    /\.edu\.hk$/,
    /\.edu\.my$/,
    /\.edu\.sg$/,
    /\.edu\.pk$/,
    /\.edu\.pl$/,
    /\.edu\.br$/,
    /\.edu\.mx$/,
    /\.edu\.co$/,
    /\.edu\.ar$/,
    /\.edu\.pe$/,
    /\.edu\.ve$/,
    /\.edu\.ec$/,
    /\.edu\.uy$/,
    /\.edu\.py$/,
    /\.edu\.cl$/,
    /\.edu\.tr$/,
    /\.edu\.vn$/,
    /\.edu\.ph$/,
    /\.edu\.tw$/,
    /\.edu\.eg$/,
    /\.edu\.ng$/,
    /\.edu\.gh$/,
    /\.edu\.ke$/,
    /\.edu\.tz$/,
    /\.edu\.et$/,
    /\.college\./,
    /\.school\./,
  ];
  return academicPatterns.some((pattern) => pattern.test(domain));
}

// AI-powered academic email validation using Gemini (for edge cases)
async function validateAcademicEmailWithAI(email: string): Promise<boolean> {
  try {
    const { GoogleGenAI } = await import("@google/genai");
    const ai = new GoogleGenAI({
      apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY,
      httpOptions: {
        apiVersion: "",
        baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
      },
    });
    
    const domain = email.split("@")[1] || "";
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ 
        role: "user", 
        parts: [{ 
          text: `You are an expert at identifying academic email domains. Is this email domain from an academic institution (university, college, school)? Domain: ${domain}. Respond ONLY with the word "true" or "false".` 
        }] 
      }],
    });
    
    const result = response.candidates?.[0]?.content?.parts?.[0]?.text?.toLowerCase().trim();
    return result === "true";
  } catch (error) {
    console.error("AI academic email validation error:", error);
    return false;
  }
}

// Session store (in-memory for MVP)
const sessions = new Map<string, { userId: string; expiresAt: Date }>();
const userActiveSessions = new Map<string, string>();

// Video duration cache (5 minute TTL)
const videoDurationCache = new Map<string, { duration: number; expiresAt: Date }>();

function getCachedDuration(url: string): number | null {
  const cached = videoDurationCache.get(url);
  if (!cached) return null;
  if (new Date() > cached.expiresAt) {
    videoDurationCache.delete(url);
    return null;
  }
  return cached.duration;
}

function setCachedDuration(url: string, duration: number): void {
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
  videoDurationCache.set(url, { duration, expiresAt });
}

async function fetchVideoDuration(url: string, platform: string): Promise<{ duration: number | null; title?: string }> {
  try {
    if (platform === "vimeo") {
      const oembedUrl = `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`;
      const response = await fetch(oembedUrl, { signal: AbortSignal.timeout(5000) });
      if (response.ok) {
        const data = await response.json();
        return { duration: data.duration || null, title: data.title };
      }
    }
    
    if (platform === "dailymotion") {
      const videoId = url.includes("dai.ly") 
        ? url.split("/").pop()?.split("?")[0]
        : url.split("/video/").pop()?.split("?")[0]?.split("_")[0];
      if (videoId) {
        const apiUrl = `https://api.dailymotion.com/video/${videoId}?fields=duration,title`;
        const response = await fetch(apiUrl, { signal: AbortSignal.timeout(5000) });
        if (response.ok) {
          const data = await response.json();
          return { duration: data.duration || null, title: data.title };
        }
      }
    }
    
    if (platform === "youtube" && process.env.YOUTUBE_API_KEY) {
      const parsedUrl = new URL(url);
      let videoId: string | null = null;
      if (parsedUrl.hostname.includes("youtu.be")) {
        videoId = parsedUrl.pathname.slice(1).split("?")[0];
      } else if (parsedUrl.pathname.startsWith("/shorts/")) {
        videoId = parsedUrl.pathname.replace("/shorts/", "").split("/")[0];
      } else {
        videoId = parsedUrl.searchParams.get("v");
      }
      
      if (videoId) {
        const apiUrl = `https://www.googleapis.com/youtube/v3/videos?id=${videoId}&part=contentDetails,snippet&key=${process.env.YOUTUBE_API_KEY}`;
        const response = await fetch(apiUrl, { signal: AbortSignal.timeout(5000) });
        if (response.ok) {
          const data = await response.json();
          if (data.items && data.items.length > 0) {
            const durationStr = data.items[0].contentDetails?.duration;
            const title = data.items[0].snippet?.title;
            if (durationStr) {
              const match = durationStr.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
              if (match) {
                const hours = parseInt(match[1] || "0");
                const minutes = parseInt(match[2] || "0");
                const seconds = parseInt(match[3] || "0");
                return { duration: hours * 3600 + minutes * 60 + seconds, title };
              }
            }
          }
        }
      }
    }
    
    return { duration: null };
  } catch (error) {
    console.error("Error fetching video duration:", error);
    return { duration: null };
  }
}

function createSession(userId: string): string {
  const previousSessionId = userActiveSessions.get(userId);
  if (previousSessionId) {
    sessions.delete(previousSessionId);
  }
  
  const sessionId = Math.random().toString(36).substring(2) + Date.now().toString(36);
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
  sessions.set(sessionId, { userId, expiresAt });
  userActiveSessions.set(userId, sessionId);
  return sessionId;
}

function getSession(sessionId: string): string | null {
  const session = sessions.get(sessionId);
  if (!session) return null;
  if (new Date() > session.expiresAt) {
    sessions.delete(sessionId);
    userActiveSessions.delete(session.userId);
    return null;
  }
  const activeSessionId = userActiveSessions.get(session.userId);
  if (activeSessionId !== sessionId) {
    return null;
  }
  return session.userId;
}

// Video URL validation - checks if URL is from supported platform with valid format
function validateVideoUrl(url: string): { valid: boolean; platform: string; error?: string } {
  try {
    const parsedUrl = new URL(url);
    const hostname = parsedUrl.hostname.toLowerCase();
    
    // YouTube patterns
    if (hostname.includes("youtube.com") || hostname.includes("youtu.be")) {
      let videoId: string | null = null;
      
      if (hostname.includes("youtu.be")) {
        // Short URL: youtu.be/{videoId}
        videoId = parsedUrl.pathname.slice(1).split("?")[0];
      } else if (parsedUrl.pathname.startsWith("/shorts/")) {
        // Shorts: youtube.com/shorts/{videoId}
        videoId = parsedUrl.pathname.replace("/shorts/", "").split("/")[0];
      } else if (parsedUrl.pathname.startsWith("/embed/")) {
        // Embed: youtube.com/embed/{videoId}
        videoId = parsedUrl.pathname.replace("/embed/", "").split("/")[0];
      } else {
        // Standard: youtube.com/watch?v={videoId}
        videoId = parsedUrl.searchParams.get("v");
      }
      
      if (!videoId || videoId.length < 11) {
        return { valid: false, platform: "youtube", error: "Invalid YouTube video URL - missing video ID" };
      }
      return { valid: true, platform: "youtube" };
    }
    
    // Vimeo patterns
    if (hostname.includes("vimeo.com")) {
      const videoId = parsedUrl.pathname.split("/").filter(Boolean).pop();
      if (!videoId || !/^\d+$/.test(videoId)) {
        return { valid: false, platform: "vimeo", error: "Invalid Vimeo video URL - missing video ID" };
      }
      return { valid: true, platform: "vimeo" };
    }
    
    // Dailymotion patterns
    if (hostname.includes("dailymotion.com") || hostname.includes("dai.ly")) {
      const pathParts = parsedUrl.pathname.split("/").filter(Boolean);
      
      // Short URL format: dai.ly/{videoId}
      if (hostname.includes("dai.ly")) {
        const videoId = pathParts[0];
        if (!videoId || videoId.length < 5) {
          return { valid: false, platform: "dailymotion", error: "Invalid Dailymotion short URL - missing video ID" };
        }
        return { valid: true, platform: "dailymotion" };
      }
      
      // Long URL format: dailymotion.com/video/{videoId}
      const videoIdx = pathParts.findIndex(p => p === "video");
      if (videoIdx === -1 || !pathParts[videoIdx + 1]) {
        return { valid: false, platform: "dailymotion", error: "Invalid Dailymotion video URL - missing video ID" };
      }
      return { valid: true, platform: "dailymotion" };
    }
    
    return { valid: false, platform: "unknown", error: "Unsupported video platform. Please use YouTube, Vimeo, or Dailymotion URLs." };
  } catch {
    return { valid: false, platform: "unknown", error: "Invalid URL format" };
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Initialize Stripe (optional - for payment processing)
  try {
    const databaseUrl = process.env.DATABASE_URL;
    if (databaseUrl) {
      console.log('Initializing Stripe schema...');
      await runMigrations({ databaseUrl });
      console.log('Stripe schema ready');
      
      const stripeSync = await getStripeSync();
      const webhookBaseUrl = `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}`;
      if (webhookBaseUrl && webhookBaseUrl !== 'https://undefined') {
        await stripeSync.findOrCreateManagedWebhook(`${webhookBaseUrl}/api/stripe/webhook`);
        console.log('Stripe webhook configured');
        stripeSync.syncBackfill().catch((err: any) => console.error('Stripe sync error:', err));
      }
    }
  } catch (error) {
    console.warn('Stripe initialization skipped:', error);
  }
  
  // Helper to get userId from session
  const getUserIdFromSession = (req: any): string | null => {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) return null;
    const sessionId = authHeader.substring(7);
    return getSession(sessionId);
  };
  
  // Auth Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      
      // Check if user exists
      const existing = await storage.getUserByEmail(data.email);
      if (existing) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      // For student tier, verify academic email using pattern matching first, then AI for edge cases
      if (data.tier === "student") {
        let isValidAcademic = isAcademicEmail(data.email);
        
        // If pattern matching fails, try AI validation for edge cases
        if (!isValidAcademic) {
          isValidAcademic = await validateAcademicEmailWithAI(data.email);
        }
        
        if (!isValidAcademic) {
          return res.status(400).json({ 
            message: "Please use a valid academic email address (.edu or university domain)" 
          });
        }
      }
      
      // Create user (password is hashed in storage layer)
      const user = await storage.createUser({
        email: data.email,
        password: data.password,
        name: data.name,
        tier: data.tier as UserTier,
      });
      
      // Generate and store verification code
      const code = generateVerificationCode();
      await storage.setVerificationCode(data.email, code);
      
      // In production, send email via Azure Communication Services
      console.log(`[DEV] Verification code for ${data.email}: ${code}`);
      
      res.json({ 
        message: "Registration successful. Please verify your email.",
        userId: user.id,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      const isPasswordValid = await storage.verifyPassword(data.password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      const sessionId = createSession(user.id);
      
      res.json({
        message: "Login successful",
        sessionId,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          tier: user.tier,
          minutesRemaining: user.minutesRemaining,
          emailVerified: user.emailVerified,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/verify", async (req, res) => {
    try {
      const data = verifySchema.parse(req.body);
      
      const isValid = await storage.verifyCode(data.email, data.code);
      if (!isValid) {
        return res.status(400).json({ message: "Invalid or expired verification code" });
      }
      
      const user = await storage.getUserByEmail(data.email);
      if (user) {
        await storage.updateUser(user.id, { emailVerified: true });
      }
      
      res.json({ message: "Email verified successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("Verification error:", error);
      res.status(500).json({ message: "Verification failed" });
    }
  });

  app.post("/api/auth/resend-code", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      const normalizedEmail = email.toLowerCase();
      const now = new Date();
      const attempts = resendAttempts.get(normalizedEmail);
      
      // Reset attempts if more than 1 hour has passed
      if (attempts && (now.getTime() - attempts.lastAttempt.getTime()) > 60 * 60 * 1000) {
        resendAttempts.delete(normalizedEmail);
      }
      
      // Check rate limit (max 3 resends per hour)
      const currentAttempts = resendAttempts.get(normalizedEmail);
      if (currentAttempts && currentAttempts.count >= 3) {
        const timeRemaining = Math.ceil((60 * 60 * 1000 - (now.getTime() - currentAttempts.lastAttempt.getTime())) / 60000);
        return res.status(429).json({ 
          message: `Too many resend attempts. Please try again in ${timeRemaining} minutes.` 
        });
      }
      
      const code = generateVerificationCode();
      await storage.setVerificationCode(email, code);
      
      // Update resend count
      resendAttempts.set(normalizedEmail, { 
        count: (currentAttempts?.count || 0) + 1, 
        lastAttempt: now 
      });
      
      // In production, send email via Azure Communication Services
      console.log(`[DEV] New verification code for ${email}: ${code}`);
      
      res.json({ message: "Verification code resent" });
    } catch (error) {
      console.error("Resend code error:", error);
      res.status(500).json({ message: "Failed to resend code" });
    }
  });

  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        // Don't reveal if user exists
        return res.json({ message: "If an account exists, a reset code has been sent" });
      }
      
      const code = generateVerificationCode();
      await storage.setVerificationCode(email, code);
      
      // In production, send email via Azure Communication Services
      console.log(`[DEV] Password reset code for ${email}: ${code}`);
      
      res.json({ message: "If an account exists, a reset code has been sent" });
    } catch (error) {
      console.error("Forgot password error:", error);
      res.status(500).json({ message: "Failed to send reset code" });
    }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { email, code, newPassword } = req.body;
      if (!email || !code || !newPassword) {
        return res.status(400).json({ message: "Email, code, and new password are required" });
      }
      
      if (newPassword.length < 8) {
        return res.status(400).json({ message: "Password must be at least 8 characters" });
      }
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify the reset code
      if (user.verificationCode !== code) {
        return res.status(400).json({ message: "Invalid reset code" });
      }
      
      if (user.verificationCodeExpiry && new Date() > user.verificationCodeExpiry) {
        return res.status(400).json({ message: "Reset code has expired" });
      }
      
      // Hash new password and update
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(user.id, { password: hashedPassword });
      
      // Clear verification code
      await storage.setVerificationCode(email, null);
      
      res.json({ message: "Password reset successfully" });
    } catch (error) {
      console.error("Reset password error:", error);
      res.status(500).json({ message: "Failed to reset password" });
    }
  });

  app.get("/api/auth/session", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader?.startsWith("Bearer ")) {
        return res.status(401).json({ message: "No session token provided" });
      }
      
      const sessionId = authHeader.substring(7);
      const userId = getSession(sessionId);
      
      if (!userId) {
        return res.status(401).json({ message: "Invalid or expired session" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          tier: user.tier,
          minutesRemaining: user.minutesRemaining,
          emailVerified: user.emailVerified,
          totalPurchases: user.totalPurchases || 0,
        },
      });
    } catch (error) {
      console.error("Session error:", error);
      res.status(500).json({ message: "Failed to get session" });
    }
  });

  // Pricing Routes
  app.post("/api/pricing/calculate", async (req, res) => {
    try {
      const data = pricingSchema.parse(req.body);
      const pricing = await storage.calculatePrice(data as PricingRequest);
      res.json(pricing);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("Pricing error:", error);
      res.status(500).json({ message: "Failed to calculate pricing" });
    }
  });

  app.get("/api/pricing/costs", async (req, res) => {
    try {
      const costs = await storage.getApiCosts();
      res.json(costs);
    } catch (error) {
      console.error("Get costs error:", error);
      res.status(500).json({ message: "Failed to get API costs" });
    }
  });

  // User Routes
  app.get("/api/user/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        id: user.id,
        email: user.email,
        name: user.name,
        tier: user.tier,
        minutesRemaining: user.minutesRemaining,
        emailVerified: user.emailVerified,
      });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  app.patch("/api/user/:id/minutes", async (req, res) => {
    try {
      const { minutes } = req.body;
      if (typeof minutes !== "number") {
        return res.status(400).json({ message: "Minutes must be a number" });
      }
      
      const user = await storage.updateUserMinutes(req.params.id, minutes);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ minutesRemaining: user.minutesRemaining });
    } catch (error) {
      console.error("Update minutes error:", error);
      res.status(500).json({ message: "Failed to update minutes" });
    }
  });

  // Video URL Validation (for pre-check before processing)
  app.post("/api/videos/validate-url", async (req, res) => {
    try {
      const { url } = req.body;
      if (!url || typeof url !== "string") {
        return res.status(400).json({ valid: false, message: "URL is required" });
      }
      
      const validation = validateVideoUrl(url);
      res.json({
        valid: validation.valid,
        platform: validation.platform,
        message: validation.error || "Valid video URL"
      });
    } catch (error) {
      console.error("URL validation error:", error);
      res.status(500).json({ valid: false, message: "Failed to validate URL" });
    }
  });

  // Get estimated video duration before processing
  app.get("/api/videos/duration", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const url = req.query.url as string;
      if (!url) {
        return res.status(400).json({ message: "URL is required" });
      }
      
      const validation = validateVideoUrl(url);
      if (!validation.valid) {
        return res.status(400).json({ message: "Invalid video URL" });
      }
      
      let durationSeconds = getCachedDuration(url);
      let videoTitle: string | undefined;
      let durationKnown = true;
      
      if (durationSeconds === null) {
        const fetched = await fetchVideoDuration(url, validation.platform);
        if (fetched.duration !== null) {
          durationSeconds = fetched.duration;
          videoTitle = fetched.title;
          setCachedDuration(url, durationSeconds);
        } else {
          durationKnown = false;
          durationSeconds = 0;
        }
      }
      
      const durationMinutes = Math.ceil(durationSeconds / 60);
      
      res.json({
        durationMinutes,
        durationSeconds,
        durationKnown,
        platform: validation.platform,
        title: videoTitle,
      });
    } catch (error) {
      console.error("Get duration error:", error);
      res.status(500).json({ message: "Failed to get video duration" });
    }
  });

  // Video Routes
  app.post("/api/videos/process", async (req, res) => {
    try {
      const data = processVideoSchema.parse(req.body);
      
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Validate video URL - check platform and format
      const videoValidation = validateVideoUrl(data.url);
      if (!videoValidation.valid) {
        return res.status(400).json({ 
          message: videoValidation.error || "Invalid video URL",
          details: "Please provide a valid YouTube, Vimeo, or Dailymotion video URL"
        });
      }
      
      // Get cached duration, fetch from API, or use user-provided estimate
      let estimatedDuration = getCachedDuration(data.url);
      if (estimatedDuration === null) {
        const fetched = await fetchVideoDuration(data.url, videoValidation.platform);
        if (fetched.duration !== null) {
          estimatedDuration = fetched.duration;
          setCachedDuration(data.url, estimatedDuration);
        } else if (data.estimatedMinutes && data.estimatedMinutes > 0) {
          estimatedDuration = data.estimatedMinutes * 60;
        } else {
          return res.status(400).json({
            message: "Could not determine video duration. Please provide an estimated duration.",
            requiresDurationInput: true,
            platform: videoValidation.platform,
          });
        }
      }
      const requiredMinutes = Math.ceil(estimatedDuration / 60);
      
      if (user.minutesRemaining < requiredMinutes) {
        return res.status(400).json({ 
          message: `Insufficient minutes. This video requires ${requiredMinutes} minutes, but you have ${user.minutesRemaining} remaining.`,
          requiredMinutes,
          remainingMinutes: user.minutesRemaining,
        });
      }
      
      // Use detected platform
      const platform = videoValidation.platform;
      
      // Create video record
      const video = await storage.createVideo({
        userId,
        url: data.url,
        title: `Video Translation - ${new Date().toLocaleString()}`,
        duration: estimatedDuration,
        platform,
        thumbnailUrl: null,
      });
      
      // Update status to processing
      await storage.updateVideoStatus(video.id, "processing");
      
      // Use AI to generate translated subtitles
      console.log(`[AI] Processing video: ${data.url} to ${data.targetLanguage}`);
      const translationResult = await transcribeAndTranslate(
        data.url,
        data.targetLanguage,
        estimatedDuration
      );
      
      // Deduct minutes after successful processing
      await storage.updateUserMinutes(userId, user.minutesRemaining - requiredMinutes);
      
      // Update status to completed
      await storage.updateVideoStatus(video.id, "completed");
      
      // Generate SRT and VTT formats
      const srtContent = formatToSRT(translationResult.segments);
      const vttContent = formatToVTT(translationResult.segments);
      
      // Create subtitle record with all formats
      const subtitle = await storage.createSubtitle({
        videoId: video.id,
        language: data.targetLanguage,
        content: JSON.stringify(translationResult.segments),
      });
      
      // Update subtitle with SRT and VTT content
      await storage.updateSubtitleFormats(subtitle.id, srtContent, vttContent);
      
      // Add to history
      await storage.addToVideoHistory(userId, video.id, data.targetLanguage);
      
      // Get updated video
      const updatedVideo = await storage.getVideo(video.id);
      
      res.json({
        message: "Video processing completed",
        video: updatedVideo,
        subtitles: {
          ...subtitle,
          srtContent,
          vttContent,
        },
        minutesDeducted: requiredMinutes,
        minutesRemaining: user.minutesRemaining - requiredMinutes,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("Process video error:", error);
      res.status(500).json({ message: "Failed to process video" });
    }
  });

  // Subtitle Settings Routes
  app.post("/api/subtitle-settings", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const data = subtitleSettingsSchema.parse(req.body);
      // Override userId with session userId for security
      const settings = await storage.saveSubtitleSettings({ ...data, userId });
      res.json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("Save settings error:", error);
      res.status(500).json({ message: "Failed to save settings" });
    }
  });

  // Shared Links Routes (requires auth for creating)
  app.post("/api/shared-links", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { videoId, password } = req.body;
      
      if (!videoId) {
        return res.status(400).json({ message: "Video ID is required" });
      }
      
      // Verify user owns this video
      const video = await storage.getVideo(videoId);
      if (!video || video.userId !== userId) {
        return res.status(403).json({ message: "You can only share your own videos" });
      }
      
      const link = await storage.createSharedLink(videoId, userId, password);
      res.json(link);
    } catch (error) {
      console.error("Create shared link error:", error);
      res.status(500).json({ message: "Failed to create shared link" });
    }
  });

  // Public shared link access - check if password protected first
  app.get("/api/shared/:shareCode", async (req, res) => {
    try {
      const link = await storage.getSharedLink(req.params.shareCode);
      if (!link) {
        return res.status(404).json({ message: "Shared link not found" });
      }
      
      // Check if link has expired
      if (link.expiresAt && new Date(link.expiresAt) < new Date()) {
        return res.status(410).json({ message: "This shared link has expired" });
      }
      
      // If password protected, only return metadata
      if (link.isPasswordProtected) {
        const video = await storage.getVideo(link.videoId);
        return res.json({
          isPasswordProtected: true,
          video: video ? { title: video.title, platform: video.platform, duration: video.duration } : null,
        });
      }
      
      const video = await storage.getVideo(link.videoId);
      const subtitles = await storage.getSubtitlesByVideo(link.videoId);
      
      res.json({
        isPasswordProtected: false,
        video,
        subtitles,
      });
    } catch (error) {
      console.error("Get shared link error:", error);
      res.status(500).json({ message: "Failed to get shared link" });
    }
  });
  
  // Verify password for protected shared links
  app.post("/api/shared/:shareCode/verify", async (req, res) => {
    try {
      const { password } = req.body;
      const link = await storage.getSharedLink(req.params.shareCode);
      
      if (!link) {
        return res.status(404).json({ message: "Shared link not found" });
      }
      
      if (!link.isPasswordProtected) {
        const video = await storage.getVideo(link.videoId);
        const subtitles = await storage.getSubtitlesByVideo(link.videoId);
        return res.json({ video, subtitles });
      }
      
      // Securely compare hashed passwords
      const isValid = await storage.verifySharedLinkPassword(link, password);
      if (!isValid) {
        return res.status(403).json({ message: "Incorrect password" });
      }
      
      const video = await storage.getVideo(link.videoId);
      const subtitles = await storage.getSubtitlesByVideo(link.videoId);
      
      res.json({ video, subtitles });
    } catch (error) {
      console.error("Verify shared link error:", error);
      res.status(500).json({ message: "Failed to verify shared link" });
    }
  });

  // Video History Routes (requires auth)
  app.get("/api/history", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const history = await storage.getVideoHistory(userId);
      res.json(history);
    } catch (error) {
      console.error("Get history error:", error);
      res.status(500).json({ message: "Failed to get video history" });
    }
  });

  // Session-authenticated endpoints
  
  // Get videos for authenticated user
  app.get("/api/videos", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const videos = await storage.getVideosByUser(userId);
      res.json(videos);
    } catch (error) {
      console.error("Get videos error:", error);
      res.status(500).json({ message: "Failed to get videos" });
    }
  });

  // Check if video was previously translated
  app.post("/api/videos/check-previous", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { url } = req.body;
      if (!url) {
        return res.status(400).json({ message: "URL is required" });
      }
      
      const video = await storage.getVideoByUrl(userId, url);
      
      if (video && video.status === "completed") {
        const subtitles = await storage.getSubtitlesByVideo(video.id);
        res.json({
          previouslyTranslated: true,
          video: {
            id: video.id,
            title: video.title,
            url: video.url,
            platform: video.platform,
            duration: video.duration,
          },
          languages: subtitles.map(s => s.language),
        });
      } else {
        res.json({ previouslyTranslated: false });
      }
    } catch (error) {
      console.error("Check previous video error:", error);
      res.status(500).json({ message: "Failed to check video" });
    }
  });
  
  // Get subtitle settings for authenticated user
  app.get("/api/subtitle-settings", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const settings = await storage.getSubtitleSettings(userId);
      if (!settings) {
        return res.json({
          fontSize: 18,
          fontColor: "#ffffff",
          backgroundColor: "rgba(0,0,0,0.7)",
          fontFamily: "Outfit",
          position: "bottom",
        });
      }
      res.json(settings);
    } catch (error) {
      console.error("Get settings error:", error);
      res.status(500).json({ message: "Failed to get settings" });
    }
  });
  
  // Get subtitles by video ID (requires auth and ownership check)
  app.get("/api/subtitles/:videoId", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Verify user owns the video
      const video = await storage.getVideo(req.params.videoId);
      if (!video || video.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const subtitles = await storage.getSubtitlesByVideo(req.params.videoId);
      res.json(subtitles);
    } catch (error) {
      console.error("Get subtitles error:", error);
      res.status(500).json({ message: "Failed to get subtitles" });
    }
  });

  // Download subtitles as SRT (paid users only)
  app.get("/api/subtitles/:videoId/download/srt", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // Check if user is paid (SRT/VTT download is for paid users only)
      if (user.tier === "free") {
        return res.status(403).json({ message: "SRT download is available for paid users only" });
      }
      
      const video = await storage.getVideo(req.params.videoId);
      if (!video || video.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const subtitles = await storage.getSubtitlesByVideo(req.params.videoId);
      if (!subtitles || subtitles.length === 0) {
        return res.status(404).json({ message: "No subtitles found" });
      }
      
      // Use the latest revision
      const latestSubtitle = subtitles[subtitles.length - 1];
      
      // Try pre-generated SRT first
      if (latestSubtitle.srtContent) {
        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="subtitles-${req.params.videoId}.srt"`);
        return res.send(latestSubtitle.srtContent);
      }
      
      // Generate SRT content from segments
      try {
        let segments;
        const content = latestSubtitle.content;
        
        if (Array.isArray(content)) {
          segments = content;
        } else if (typeof content === "string") {
          segments = JSON.parse(content);
        } else if (content && typeof content === "object") {
          segments = Array.isArray(Object.values(content)) ? Object.values(content) : [content];
        } else {
          return res.status(404).json({ message: "Invalid subtitle content format" });
        }
        
        if (!Array.isArray(segments) || segments.length === 0) {
          return res.status(404).json({ message: "No subtitle segments found" });
        }
        
        const srtContent = formatToSRT(segments);
        
        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="subtitles-${req.params.videoId}.srt"`);
        res.send(srtContent);
      } catch (parseError) {
        console.error("SRT generation error:", parseError);
        res.status(500).json({ message: "Failed to generate SRT file" });
      }
    } catch (error) {
      console.error("Download SRT error:", error);
      res.status(500).json({ message: "Failed to download SRT" });
    }
  });

  // Download subtitles as VTT (paid users only)
  app.get("/api/subtitles/:videoId/download/vtt", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // Check if user is paid (SRT/VTT download is for paid users only)
      if (user.tier === "free") {
        return res.status(403).json({ message: "VTT download is available for paid users only" });
      }
      
      const video = await storage.getVideo(req.params.videoId);
      if (!video || video.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const subtitles = await storage.getSubtitlesByVideo(req.params.videoId);
      if (!subtitles || subtitles.length === 0) {
        return res.status(404).json({ message: "No subtitles found" });
      }
      
      // Use the latest revision
      const latestSubtitle = subtitles[subtitles.length - 1];
      
      // Try pre-generated VTT first
      if (latestSubtitle.vttContent) {
        res.setHeader("Content-Type", "text/vtt; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="subtitles-${req.params.videoId}.vtt"`);
        return res.send(latestSubtitle.vttContent);
      }
      
      // Generate VTT content from segments
      try {
        let segments;
        const content = latestSubtitle.content;
        
        if (Array.isArray(content)) {
          segments = content;
        } else if (typeof content === "string") {
          segments = JSON.parse(content);
        } else if (content && typeof content === "object") {
          segments = Array.isArray(Object.values(content)) ? Object.values(content) : [content];
        } else {
          return res.status(404).json({ message: "Invalid subtitle content format" });
        }
        
        if (!Array.isArray(segments) || segments.length === 0) {
          return res.status(404).json({ message: "No subtitle segments found" });
        }
        
        const vttContent = formatToVTT(segments);
        
        res.setHeader("Content-Type", "text/vtt; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="subtitles-${req.params.videoId}.vtt"`);
        res.send(vttContent);
      } catch {
        res.status(500).json({ message: "Failed to generate VTT file" });
      }
    } catch (error) {
      console.error("Download VTT error:", error);
      res.status(500).json({ message: "Failed to download VTT" });
    }
  });
  
  // Create Stripe checkout session for buying minutes
  app.post("/api/checkout/minutes", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { minutes } = req.body;
      if (!minutes || typeof minutes !== "number" || minutes < 350) {
        return res.status(400).json({ message: "Minimum 350 minutes required" });
      }
      if (minutes > MAX_MINUTES_PER_PURCHASE) {
        return res.status(400).json({ message: `Maximum ${MAX_MINUTES_PER_PURCHASE} minutes per purchase` });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Calculate price based on tier
      const pricing = await storage.calculatePrice({ minutes, tier: user.tier as any });
      const pricePerMinute = pricing.finalPrice / minutes;
      
      // Create or get Stripe customer
      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripeService.createCustomer(user.email, userId);
        await storage.updateUser(userId, { stripeCustomerId: customer.id });
        customerId = customer.id;
      }
      
      // Create checkout session
      const protocol = req.get('x-forwarded-proto') || req.protocol;
      const host = req.get('host');
      const baseUrl = `${protocol}://${host}`;
      
      const session = await stripeService.createMinutesCheckoutSession(
        customerId,
        minutes,
        pricePerMinute,
        `${baseUrl}/dashboard?payment=success&minutes=${minutes}`,
        `${baseUrl}/dashboard?payment=cancelled`,
        userId
      );
      
      res.json({ url: session.url });
    } catch (error) {
      console.error("Checkout error:", error);
      res.status(500).json({ message: "Failed to create checkout session" });
    }
  });
  
  // Get Stripe publishable key
  app.get("/api/stripe/publishable-key", async (req, res) => {
    try {
      const publishableKey = await getStripePublishableKey();
      res.json({ publishableKey });
    } catch (error) {
      console.error("Get publishable key error:", error);
      res.status(500).json({ message: "Failed to get Stripe key" });
    }
  });
  
  // Buy more minutes (admin/testing only - does not count toward purchase eligibility)
  // Real purchases go through Stripe checkout and webhook
  app.post("/api/users/buy-minutes", async (req, res) => {
    try {
      // Only allow in development mode
      if (process.env.NODE_ENV === "production") {
        return res.status(403).json({ message: "This endpoint is disabled in production. Use Stripe checkout." });
      }
      
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { minutes } = req.body;
      if (!minutes || typeof minutes !== "number") {
        return res.status(400).json({ message: "Minutes must be a number" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const newMinutes = user.minutesRemaining + minutes;
      await storage.updateUserMinutes(userId, newMinutes);
      
      // Note: This test endpoint does NOT increment totalPurchases
      // Real purchases increment it via Stripe webhook
      
      res.json({ 
        message: "Test purchase successful (development only)",
        minutesAdded: minutes,
        minutesRemaining: newMinutes,
      });
    } catch (error) {
      console.error("Buy minutes error:", error);
      res.status(500).json({ message: "Failed to purchase minutes" });
    }
  });

  // Get active discount codes for paid users (for dashboard banner)
  app.get("/api/discount-codes/active", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Only paid users can see discount codes
      if (user.tier === "free") {
        return res.json([]);
      }
      
      // Only show if user has at least one purchase (codes apply from 2nd purchase)
      if ((user.totalPurchases || 0) < 1) {
        return res.json([]);
      }
      
      const allCodes = await storage.getAllDiscountCodes();
      const now = new Date();
      
      // Filter to only currently active codes
      const activeCodes = allCodes.filter(code => {
        return now >= code.startDate && now <= code.endDate;
      }).map(code => ({
        id: code.id,
        code: code.code,
        discountValue: code.discountValue,
        startDate: code.startDate,
        endDate: code.endDate,
      }));
      
      res.json(activeCodes);
    } catch (error) {
      console.error("Get active discount codes error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Validate discount code
  app.post("/api/discount-codes/validate", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { code } = req.body;
      if (!code || typeof code !== "string") {
        return res.status(400).json({ valid: false, message: "Code is required" });
      }
      
      // Get user and check tier eligibility
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ valid: false, message: "User not found" });
      }
      
      // Discount codes only apply to Standard and Student tiers
      if (user.tier === "free") {
        return res.json({ valid: false, message: "Discount codes are only available for Standard and Student tiers" });
      }
      
      // Check if user has made at least one purchase (discount applies from 2nd purchase onwards)
      const purchaseCount = user.totalPurchases || 0;
      if (purchaseCount < 1) {
        return res.json({ valid: false, message: "Discount codes apply starting from your second purchase" });
      }
      
      const discountCode = await storage.getDiscountCode(code);
      if (!discountCode) {
        return res.json({ valid: false });
      }
      
      const now = new Date();
      if (now < discountCode.startDate || now > discountCode.endDate) {
        return res.json({ valid: false });
      }
      
      res.json({ 
        valid: true, 
        discountValue: discountCode.discountValue,
        discountType: discountCode.discountType
      });
    } catch (error) {
      console.error("Validate discount error:", error);
      res.json({ valid: false });
    }
  });

  // Admin routes
  app.get("/api/admin/users", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const users = await storage.getAllUsers();
      res.json(users.map(u => ({ ...u, password: undefined })));
    } catch (error) {
      console.error("Get admin users error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/admin/users/:userId/tier", async (req, res) => {
    try {
      const adminId = getUserIdFromSession(req);
      if (!adminId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const adminUser = await storage.getUser(adminId);
      if (!adminUser || !adminUser.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { userId } = req.params;
      const { tier } = req.body;
      
      await storage.updateUser(userId, { tier });
      res.json({ success: true });
    } catch (error) {
      console.error("Update user tier error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/users/:userId/add-minutes", async (req, res) => {
    try {
      const adminId = getUserIdFromSession(req);
      if (!adminId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const adminUser = await storage.getUser(adminId);
      if (!adminUser || !adminUser.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { userId } = req.params;
      const { minutes } = req.body;
      
      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      await storage.updateUserMinutes(userId, targetUser.minutesRemaining + minutes);
      res.json({ success: true });
    } catch (error) {
      console.error("Add minutes error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/settings", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const settings = await storage.getApiCosts();
      res.json(settings);
    } catch (error) {
      console.error("Get admin settings error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/admin/settings", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const settings = await storage.updateApiCosts(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Update admin settings error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/discount-codes", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const codes = await storage.getAllDiscountCodes();
      res.json(codes);
    } catch (error) {
      console.error("Get discount codes error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/discount-codes", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { code, discountValue, startDate, endDate } = req.body;
      const discountCode = await storage.createDiscountCode(
        code, 
        discountValue, 
        new Date(startDate), 
        new Date(endDate),
        user.id
      );
      res.json(discountCode);
    } catch (error) {
      console.error("Create discount code error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/admin/discount-codes/:codeId", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      await storage.deleteDiscountCode(req.params.codeId);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete discount code error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Export analytics data for admin
  app.get("/api/admin/analytics/export", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Get all analytics data
      const users = await storage.getAllUsers();
      const payments = await storage.getAllPayments();
      const videos = await storage.getAllVideos();
      const fiscalYears = await storage.getFiscalYears();
      const fiscalStats = await storage.getFiscalStats();
      
      // Calculate summary statistics
      const totalUsers = users.length;
      const paidUsers = users.filter(u => u.tier !== "free").length;
      const studentUsers = users.filter(u => u.tier === "student").length;
      const totalMinutesUsed = users.reduce((sum, u) => sum + (u.totalMinutesUsed || 0), 0);
      const totalRevenue = payments.reduce((sum, p) => sum + (p.amount || 0), 0);
      
      const exportData = {
        exportDate: new Date().toISOString(),
        summary: {
          totalUsers,
          paidUsers,
          studentUsers,
          freeUsers: totalUsers - paidUsers,
          totalVideosProcessed: videos.length,
          totalMinutesUsed,
          totalRevenue: totalRevenue / 100,
          averageRevenuePerUser: paidUsers > 0 ? (totalRevenue / 100) / paidUsers : 0,
        },
        fiscalYears: fiscalYears.map(fy => ({
          year: fy.yearNumber,
          startDate: fy.startDate,
          endDate: fy.endDate,
          totalPayments: fy.totalPayments / 100,
          totalTax: fy.totalTax / 100,
          totalVat: fy.totalVat / 100,
          isPaid: fy.isPaid,
        })),
        recentPayments: payments.slice(0, 50).map(p => ({
          date: p.createdAt,
          amount: p.amount ? p.amount / 100 : 0,
          minutes: p.minutesPurchased,
          tier: p.tierAtPurchase,
        })),
        userDistribution: {
          free: users.filter(u => u.tier === "free").length,
          standard: users.filter(u => u.tier === "standard").length,
          student: users.filter(u => u.tier === "student").length,
        },
      };
      
      res.json(exportData);
    } catch (error) {
      console.error("Export analytics error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/fiscal-stats", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const stats = await storage.getFiscalStats();
      res.json(stats);
    } catch (error) {
      console.error("Get fiscal stats error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Fiscal Years Management
  app.get("/api/admin/fiscal-years", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const fiscalYears = await storage.getFiscalYears();
      res.json(fiscalYears);
    } catch (error) {
      console.error("Get fiscal years error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/fiscal-years/:yearId/mark-paid", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updated = await storage.markFiscalYearPaid(req.params.yearId);
      if (!updated) {
        return res.status(404).json({ message: "Fiscal year not found" });
      }
      
      await storage.createAdminLog(userId, "mark_fiscal_year_paid", "fiscal_year", req.params.yearId);
      res.json(updated);
    } catch (error) {
      console.error("Mark fiscal year paid error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Generate PDF report for fiscal year
  app.get("/api/admin/fiscal-years/:yearId/pdf", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const fiscalYears = await storage.getFiscalYears();
      const fiscalYear = fiscalYears.find(fy => fy.id === req.params.yearId);
      
      if (!fiscalYear) {
        return res.status(404).json({ message: "Fiscal year not found" });
      }
      
      const stats = await storage.getFiscalStats();
      const PDFDocument = (await import("pdfkit")).default;
      
      const doc = new PDFDocument({ margin: 50 });
      
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=fiscal-report-${fiscalYear.year}.pdf`);
      
      doc.pipe(res);
      
      doc.fontSize(24).font("Helvetica-Bold").text("Erzino - Fiscal Year Report", { align: "center" });
      doc.moveDown();
      doc.fontSize(16).font("Helvetica").text(`Year: ${fiscalYear.year}`, { align: "center" });
      doc.moveDown(2);
      
      doc.fontSize(14).font("Helvetica-Bold").text("Financial Summary", { underline: true });
      doc.moveDown();
      
      doc.fontSize(12).font("Helvetica");
      doc.text(`Total Revenue: €${(Number(fiscalYear.totalPayments) / 100).toFixed(2)}`);
      doc.text(`Total Tax Collected: €${(Number(fiscalYear.totalTax) / 100).toFixed(2)}`);
      doc.text(`Total VAT Collected: €${(Number(fiscalYear.totalVat) / 100).toFixed(2)}`);
      doc.text(`VAT Status: ${fiscalYear.vatActive ? "Active (18%)" : "Not Active"}`);
      doc.text(`VAT Threshold: €30,000`);
      doc.text(`Payment Status: ${fiscalYear.isPaid ? "PAID" : "PENDING"}`);
      
      if (fiscalYear.paidAt) {
        doc.text(`Paid On: ${new Date(fiscalYear.paidAt).toLocaleDateString()}`);
      }
      
      doc.moveDown(2);
      doc.fontSize(14).font("Helvetica-Bold").text("Platform Statistics", { underline: true });
      doc.moveDown();
      
      doc.fontSize(12).font("Helvetica");
      doc.text(`Total Users: ${stats.totalUsers}`);
      doc.text(`Paid Users: ${stats.paidUsers}`);
      doc.text(`Total Minutes Sold: ${stats.totalMinutesSold}`);
      doc.text(`Overall Revenue: €${(stats.totalRevenue / 100).toFixed(2)}`);
      
      doc.moveDown(2);
      doc.fontSize(10).text(`Report generated on: ${new Date().toLocaleString()}`, { align: "right" });
      doc.text("Erzino AI Video Translation Platform", { align: "right" });
      
      doc.end();
      
      await storage.createAdminLog(userId, "download_fiscal_report", "fiscal_year", req.params.yearId);
    } catch (error) {
      console.error("Generate fiscal PDF error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Ads Config Management
  app.get("/api/admin/ads-config", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const configs = await storage.getAllAdsConfig();
      res.json(configs);
    } catch (error) {
      console.error("Get ads config error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/ads-config", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { providerName, adCode, placement, enabled } = req.body;
      const config = await storage.createAdsConfig({ providerName, adCode, placement, enabled });
      await storage.createAdminLog(userId, "create_ads_config", "ads_config", config.id);
      res.json(config);
    } catch (error) {
      console.error("Create ads config error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/admin/ads-config/:configId", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updated = await storage.updateAdsConfig(req.params.configId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Ads config not found" });
      }
      
      await storage.createAdminLog(userId, "update_ads_config", "ads_config", req.params.configId);
      res.json(updated);
    } catch (error) {
      console.error("Update ads config error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/admin/ads-config/:configId", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      await storage.deleteAdsConfig(req.params.configId);
      await storage.createAdminLog(userId, "delete_ads_config", "ads_config", req.params.configId);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete ads config error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get ads for display (for Free users and shared links)
  app.get("/api/ads", async (req, res) => {
    try {
      const placement = req.query.placement as string || "free_tier";
      const configs = await storage.getAllAdsConfig();
      const activeAds = configs.filter(c => c.enabled && (c.placement === placement || c.placement === "both"));
      res.json(activeAds);
    } catch (error) {
      console.error("Get ads error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin Logs
  app.get("/api/admin/logs", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const logs = await storage.getAdminLogs();
      res.json(logs);
    } catch (error) {
      console.error("Get admin logs error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin: Suspend user
  app.post("/api/admin/users/:userId/suspend", async (req, res) => {
    try {
      const adminId = getUserIdFromSession(req);
      if (!adminId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const adminUser = await storage.getUser(adminId);
      if (!adminUser || !adminUser.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { userId } = req.params;
      const { reason } = req.body;
      
      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (targetUser.isAdmin) {
        return res.status(400).json({ message: "Cannot suspend an admin user" });
      }
      
      await storage.updateUser(userId, { 
        isSuspended: true, 
        suspendedReason: reason || "Account suspended by admin",
        suspendedAt: new Date()
      });
      
      await storage.createAdminLog(adminId, "suspend_user", "user", userId, JSON.stringify({ reason }));
      res.json({ success: true });
    } catch (error) {
      console.error("Suspend user error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin: Unsuspend user
  app.post("/api/admin/users/:userId/unsuspend", async (req, res) => {
    try {
      const adminId = getUserIdFromSession(req);
      if (!adminId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const adminUser = await storage.getUser(adminId);
      if (!adminUser || !adminUser.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { userId } = req.params;
      
      await storage.updateUser(userId, { 
        isSuspended: false, 
        suspendedReason: null,
        suspendedAt: null
      });
      
      await storage.createAdminLog(adminId, "unsuspend_user", "user", userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Unsuspend user error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin: Delete user
  app.delete("/api/admin/users/:userId", async (req, res) => {
    try {
      const adminId = getUserIdFromSession(req);
      if (!adminId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const adminUser = await storage.getUser(adminId);
      if (!adminUser || !adminUser.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { userId } = req.params;
      
      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (targetUser.isAdmin) {
        return res.status(400).json({ message: "Cannot delete an admin user" });
      }
      
      await storage.deleteUser(userId);
      await storage.createAdminLog(adminId, "delete_user", "user", userId, JSON.stringify({ email: targetUser.email }));
      res.json({ success: true });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin: Send notification to user
  app.post("/api/admin/users/:userId/notify", async (req, res) => {
    try {
      const adminId = getUserIdFromSession(req);
      if (!adminId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const adminUser = await storage.getUser(adminId);
      if (!adminUser || !adminUser.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { userId } = req.params;
      const { title, message, type } = req.body;
      
      if (!title || !message) {
        return res.status(400).json({ message: "Title and message are required" });
      }
      
      const notification = await storage.createUserNotification({
        userId,
        title,
        message,
        type: type || "info",
        sentBy: adminId,
      });
      
      await storage.createAdminLog(adminId, "send_notification", "user", userId, JSON.stringify({ title }));
      res.json(notification);
    } catch (error) {
      console.error("Send notification error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // User: Get notifications
  app.get("/api/notifications", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Get notifications error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // User: Mark notification as read
  app.patch("/api/notifications/:notificationId/read", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      await storage.markNotificationAsRead(req.params.notificationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark notification read error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Check if video was previously translated in a specific language
  app.get("/api/videos/check-translation", async (req, res) => {
    try {
      const userId = getUserIdFromSession(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { videoId, language } = req.query;
      if (!videoId || !language) {
        return res.status(400).json({ message: "Video ID and language are required" });
      }
      
      const subtitle = await storage.getSubtitleByVideoAndLanguage(videoId as string, language as string);
      res.json({ 
        exists: !!subtitle,
        subtitle: subtitle || null
      });
    } catch (error) {
      console.error("Check translation error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  return httpServer;
}
