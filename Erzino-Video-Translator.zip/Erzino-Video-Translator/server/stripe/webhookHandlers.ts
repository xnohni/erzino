import { getStripeSync, getUncachableStripeClient } from './stripeClient';
import { storage } from '../storage';

export class WebhookHandlers {
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    if (!Buffer.isBuffer(payload)) {
      throw new Error(
        'STRIPE WEBHOOK ERROR: Payload must be a Buffer. ' +
        'Received type: ' + typeof payload + '. ' +
        'FIX: Ensure webhook route is registered BEFORE app.use(express.json()).'
      );
    }

    const stripe = await getUncachableStripeClient();
    const sync = await getStripeSync();
    
    // Get webhook secret from stripe-replit-sync
    const webhookSecret = sync.getWebhookSecret?.() || process.env.STRIPE_WEBHOOK_SECRET;
    
    // Parse and verify the event
    let event;
    try {
      event = webhookSecret 
        ? stripe.webhooks.constructEvent(payload, signature, webhookSecret)
        : JSON.parse(payload.toString());
    } catch (err: any) {
      console.error('Webhook signature verification failed:', err.message);
      throw err;
    }
    
    // Handle checkout.session.completed for minute purchases
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      
      if (session.metadata?.type === 'minute_purchase') {
        const sessionId = session.id;
        const userId = session.metadata.userId;
        const minutes = parseInt(session.metadata.minutes, 10);
        
        if (userId && !isNaN(minutes) && sessionId) {
          try {
            // Idempotency check: has this session already been processed?
            const existingPayment = await storage.getPaymentBySessionId(sessionId);
            if (existingPayment) {
              console.log(`Webhook: Session ${sessionId} already processed, skipping duplicate`);
            } else {
              const user = await storage.getUser(userId);
              if (user) {
                // Record the payment first (for idempotency)
                await storage.createPayment(
                  sessionId, 
                  userId, 
                  session.amount_total || 0, 
                  minutes
                );
                
                // Add minutes to user
                const newMinutes = user.minutesRemaining + minutes;
                await storage.updateUserMinutes(userId, newMinutes);
                
                // Increment purchase count for discount eligibility
                const newPurchaseCount = (user.totalPurchases || 0) + 1;
                
                // Auto-upgrade Free tier to Standard after first purchase
                const updates: { totalPurchases: number; tier?: string } = { 
                  totalPurchases: newPurchaseCount 
                };
                
                if (user.tier === 'free') {
                  updates.tier = 'standard';
                  console.log(`Webhook: Auto-upgrading user ${userId} from Free to Standard tier`);
                }
                
                await storage.updateUser(userId, updates);
                
                // Create invoice record and update fiscal year
                const pricing = await storage.calculatePrice({ minutes, tier: user.tier as any });
                await storage.createOrUpdateFiscalYear(
                  pricing.finalPrice,
                  pricing.tax,
                  pricing.vat
                );
                
                // Log invoice
                await storage.createInvoiceRecord({
                  userId,
                  paymentId: sessionId,
                  amount: pricing.finalPrice,
                  minutes,
                  apiCost: pricing.apiCost,
                  profit: pricing.profit,
                  vatAmount: pricing.vat,
                  taxAmount: pricing.tax,
                  discountAmount: pricing.discount,
                  tier: user.tier,
                });
                
                console.log(`Webhook: Added ${minutes} minutes to user ${userId}. Total: ${newMinutes}. Purchases: ${newPurchaseCount}`);
              }
            }
          } catch (err) {
            console.error('Error processing minute purchase webhook:', err);
          }
        }
      }
    }

    // Pass through to stripe-replit-sync for standard processing
    await sync.processWebhook(payload, signature);
  }
}
