import { getUncachableStripeClient } from './stripeClient';
import { storage } from '../storage';

export class StripeService {
  async createCustomer(email: string, userId: string) {
    const stripe = await getUncachableStripeClient();
    return await stripe.customers.create({
      email,
      metadata: { userId },
    });
  }

  async createMinutesCheckoutSession(
    customerId: string,
    minutes: number,
    pricePerMinute: number,
    successUrl: string,
    cancelUrl: string,
    userId: string
  ) {
    const stripe = await getUncachableStripeClient();
    const unitAmountCents = Math.round(pricePerMinute * 100);
    
    return await stripe.checkout.sessions.create({
      customer: customerId,
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: `Translation Minutes`,
            description: `Purchase ${minutes} minutes for video translation on Erzino`,
          },
          unit_amount: unitAmountCents,
        },
        quantity: minutes,
      }],
      mode: 'payment',
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: {
        userId,
        minutes: String(minutes),
        type: 'minute_purchase',
      },
    });
  }

  async createCustomerPortalSession(customerId: string, returnUrl: string) {
    const stripe = await getUncachableStripeClient();
    return await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    });
  }
}

export const stripeService = new StripeService();
