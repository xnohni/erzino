import {
  type User,
  type InsertUser,
  type Video,
  type InsertVideo,
  type Subtitle,
  type InsertSubtitle,
  type SubtitleSettings,
  type InsertSubtitleSettings,
  type SettingsApiCosts,
  type SharedVideoLink,
  type VideoHistory,
  type UserTier,
  type PricingRequest,
  type PricingResponse,
  type DiscountCode,
  type Payment,
  type AdsConfig,
  type InsertAdsConfig,
  type AdminLog,
  type InvoiceRecord,
  type FiscalYear,
  type DiscountCodeUsage,
  users,
  videos,
  subtitles,
  subtitleSettings,
  settingsApiCosts,
  sharedVideoLinks,
  videoHistory,
  discountCodes,
  payments,
  adsConfig,
  adminLogs,
  invoiceRecords,
  fiscalYears,
  discountCodeUsage,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser & { name: string; tier: UserTier }): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  updateUserMinutes(id: string, minutes: number): Promise<User | undefined>;
  verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean>;

  getVideo(id: string): Promise<Video | undefined>;
  getVideosByUser(userId: string): Promise<Video[]>;
  getVideoByUrl(userId: string, url: string): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideoStatus(id: string, status: string): Promise<Video | undefined>;

  getSubtitle(id: string): Promise<Subtitle | undefined>;
  getSubtitlesByVideo(videoId: string): Promise<Subtitle[]>;
  createSubtitle(subtitle: InsertSubtitle): Promise<Subtitle>;
  updateSubtitleFormats(id: string, srtContent: string, vttContent: string): Promise<Subtitle | undefined>;

  getSubtitleSettings(userId: string): Promise<SubtitleSettings | undefined>;
  saveSubtitleSettings(settings: InsertSubtitleSettings): Promise<SubtitleSettings>;

  getApiCosts(): Promise<SettingsApiCosts>;
  calculatePrice(request: PricingRequest): Promise<PricingResponse>;

  getSharedLink(shareCode: string): Promise<SharedVideoLink | undefined>;
  createSharedLink(videoId: string, userId: string, password?: string): Promise<SharedVideoLink>;
  verifySharedLinkPassword(link: SharedVideoLink, password: string): Promise<boolean>;

  getVideoHistory(userId: string): Promise<VideoHistory[]>;
  addToVideoHistory(userId: string, videoId: string, language: string): Promise<VideoHistory>;

  setVerificationCode(email: string, code: string | null): Promise<void>;
  verifyCode(email: string, code: string): Promise<boolean>;
  
  getDiscountCode(code: string): Promise<DiscountCode | undefined>;
  getAllDiscountCodes(): Promise<DiscountCode[]>;
  createDiscountCode(code: string, discountValue: number, startDate: Date, endDate: Date, createdBy?: string): Promise<DiscountCode>;
  deleteDiscountCode(id: string): Promise<void>;
  incrementDiscountCodeUsage(id: string): Promise<void>;
  
  getPaymentBySessionId(sessionId: string): Promise<Payment | undefined>;
  createPayment(sessionId: string, userId: string, amount: number, minutes: number): Promise<Payment>;
  
  getAllUsers(): Promise<User[]>;
  updateApiCosts(settings: Partial<SettingsApiCosts>): Promise<SettingsApiCosts>;
  getFiscalStats(): Promise<{ totalRevenue: number; totalMinutesSold: number; totalUsers: number; paidUsers: number }>;
  
  getAllAdsConfig(): Promise<AdsConfig[]>;
  createAdsConfig(config: InsertAdsConfig): Promise<AdsConfig>;
  updateAdsConfig(id: string, updates: Partial<AdsConfig>): Promise<AdsConfig | undefined>;
  deleteAdsConfig(id: string): Promise<void>;
  
  createAdminLog(adminId: string, action: string, targetType?: string, targetId?: string, details?: string, ipAddress?: string): Promise<AdminLog>;
  getAdminLogs(): Promise<AdminLog[]>;
  
  createInvoiceRecord(data: { userId: string; paymentId: string; amount: number; minutes: number; apiCost: number; profit: number; vatAmount: number; taxAmount: number; discountAmount: number; discountCodeId?: string; tier: string }): Promise<InvoiceRecord>;
  getInvoiceRecords(): Promise<InvoiceRecord[]>;
  
  getFiscalYears(): Promise<FiscalYear[]>;
  getCurrentFiscalYear(): Promise<FiscalYear | undefined>;
  createOrUpdateFiscalYear(paymentAmount: number, taxAmount: number, vatAmount: number): Promise<FiscalYear>;
  markFiscalYearPaid(id: string): Promise<FiscalYear | undefined>;
  
  logDiscountCodeUsage(discountCodeId: string, userId: string, paymentId: string, discountValue: number, tier: string): Promise<DiscountCodeUsage>;
  
  getSubtitleByVideoAndLanguage(videoId: string, language: string): Promise<Subtitle | undefined>;
  
  deleteUser(id: string): Promise<void>;
  
  createUserNotification(data: { userId: string; title: string; message: string; type: string; sentBy?: string }): Promise<any>;
  getUserNotifications(userId: string): Promise<any[]>;
  markNotificationAsRead(notificationId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  private verificationCodes: Map<string, { code: string; expiry: Date }>;

  constructor() {
    this.verificationCodes = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email.toLowerCase()));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser & { name: string; tier: UserTier }): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 12);
    const [user] = await db
      .insert(users)
      .values({
        email: insertUser.email.toLowerCase(),
        password: hashedPassword,
        name: insertUser.name,
        tier: insertUser.tier,
        minutesRemaining: insertUser.tier === "free" ? 30 : 0,
        emailVerified: false,
        studentEmailDomainValid: insertUser.tier === "student",
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async updateUserMinutes(id: string, minutes: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ minutesRemaining: minutes })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(plainPassword, hashedPassword);
  }

  async getVideo(id: string): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video || undefined;
  }

  async getVideosByUser(userId: string): Promise<Video[]> {
    return db.select().from(videos).where(eq(videos.userId, userId)).orderBy(desc(videos.createdAt));
  }

  async getVideoByUrl(userId: string, url: string): Promise<Video | undefined> {
    const [video] = await db
      .select()
      .from(videos)
      .where(and(eq(videos.userId, userId), eq(videos.url, url)))
      .orderBy(desc(videos.createdAt))
      .limit(1);
    return video || undefined;
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values(insertVideo).returning();
    return video;
  }

  async updateVideoStatus(id: string, status: string): Promise<Video | undefined> {
    const [video] = await db
      .update(videos)
      .set({ status })
      .where(eq(videos.id, id))
      .returning();
    return video || undefined;
  }

  async getSubtitle(id: string): Promise<Subtitle | undefined> {
    const [subtitle] = await db.select().from(subtitles).where(eq(subtitles.id, id));
    return subtitle || undefined;
  }

  async getSubtitlesByVideo(videoId: string): Promise<Subtitle[]> {
    return db.select().from(subtitles).where(eq(subtitles.videoId, videoId));
  }

  async createSubtitle(insertSubtitle: InsertSubtitle): Promise<Subtitle> {
    const [subtitle] = await db.insert(subtitles).values(insertSubtitle).returning();
    return subtitle;
  }

  async updateSubtitleFormats(id: string, srtContent: string, vttContent: string): Promise<Subtitle | undefined> {
    const [subtitle] = await db
      .update(subtitles)
      .set({ srtContent, vttContent })
      .where(eq(subtitles.id, id))
      .returning();
    return subtitle || undefined;
  }

  async getSubtitleSettings(userId: string): Promise<SubtitleSettings | undefined> {
    const [settings] = await db.select().from(subtitleSettings).where(eq(subtitleSettings.userId, userId));
    return settings || undefined;
  }

  async saveSubtitleSettings(settings: InsertSubtitleSettings): Promise<SubtitleSettings> {
    const existing = await this.getSubtitleSettings(settings.userId);
    if (existing) {
      const [updated] = await db
        .update(subtitleSettings)
        .set(settings)
        .where(eq(subtitleSettings.userId, settings.userId))
        .returning();
      return updated;
    }
    const [created] = await db.insert(subtitleSettings).values(settings).returning();
    return created;
  }

  async getApiCosts(): Promise<SettingsApiCosts> {
    const [costs] = await db.select().from(settingsApiCosts);
    if (costs) return costs;
    const [created] = await db
      .insert(settingsApiCosts)
      .values({
        gpt4oTranscribeCost: 0.0062,
        gpt4oMiniCost: 0.00053,
        profitMargin: 0.26,
        vatPercentage: 0,
        taxPercentage: 0,
        studentDiscount: 0.17,
      })
      .returning();
    return created;
  }

  async calculatePrice(request: PricingRequest): Promise<PricingResponse> {
    const costs = await this.getApiCosts();
    const totalApiCostPerMinute = costs.gpt4oTranscribeCost + costs.gpt4oMiniCost;
    
    const apiCost = request.minutes * totalApiCostPerMinute;
    const profit = apiCost * costs.profitMargin;
    const subtotal = apiCost + profit;
    const vat = subtotal * costs.vatPercentage;
    const tax = subtotal * costs.taxPercentage;
    
    let discount = 0;
    if (request.tier === "student") {
      discount = (subtotal + vat + tax) * costs.studentDiscount;
    }
    
    const finalPrice = Math.round((subtotal + vat + tax - discount) * 100) / 100;
    
    return {
      minutes: request.minutes,
      apiCost: Math.round(apiCost * 100) / 100,
      profit: Math.round(profit * 100) / 100,
      vat: Math.round(vat * 100) / 100,
      tax: Math.round(tax * 100) / 100,
      discount: Math.round(discount * 100) / 100,
      finalPrice,
      pricePerMinute: Math.round((finalPrice / request.minutes) * 10000) / 10000,
    };
  }

  async getSharedLink(shareCode: string): Promise<SharedVideoLink | undefined> {
    const [link] = await db.select().from(sharedVideoLinks).where(eq(sharedVideoLinks.shareCode, shareCode));
    return link || undefined;
  }

  async createSharedLink(videoId: string, userId: string, password?: string): Promise<SharedVideoLink> {
    const shareCode = randomUUID().substring(0, 8);
    // Hash password if provided
    const hashedPassword = password ? await bcrypt.hash(password, 10) : null;
    const [link] = await db
      .insert(sharedVideoLinks)
      .values({
        videoId,
        userId,
        shareCode,
        password: hashedPassword,
        isPasswordProtected: !!password,
      })
      .returning();
    return link;
  }
  
  async verifySharedLinkPassword(link: SharedVideoLink, password: string): Promise<boolean> {
    if (!link.password) return false;
    return bcrypt.compare(password, link.password);
  }

  async getVideoHistory(userId: string): Promise<VideoHistory[]> {
    return db
      .select()
      .from(videoHistory)
      .where(eq(videoHistory.userId, userId))
      .orderBy(desc(videoHistory.watchedAt))
      .limit(50);
  }

  async addToVideoHistory(userId: string, videoId: string, language: string): Promise<VideoHistory> {
    const [history] = await db
      .insert(videoHistory)
      .values({ userId, videoId, language })
      .returning();
    return history;
  }

  async setVerificationCode(email: string, code: string | null): Promise<void> {
    if (code === null) {
      this.verificationCodes.delete(email.toLowerCase());
      await db
        .update(users)
        .set({ 
          verificationCode: null, 
          verificationCodeExpiry: null 
        })
        .where(eq(users.email, email.toLowerCase()));
    } else {
      const expiry = new Date(Date.now() + 10 * 60 * 1000);
      this.verificationCodes.set(email.toLowerCase(), { code, expiry });
      await db
        .update(users)
        .set({ 
          verificationCode: code, 
          verificationCodeExpiry: expiry 
        })
        .where(eq(users.email, email.toLowerCase()));
    }
  }

  async verifyCode(email: string, code: string): Promise<boolean> {
    const stored = this.verificationCodes.get(email.toLowerCase());
    if (stored) {
      if (new Date() > stored.expiry) {
        this.verificationCodes.delete(email.toLowerCase());
        return false;
      }
      if (stored.code !== code) return false;
      this.verificationCodes.delete(email.toLowerCase());
      return true;
    }
    const user = await this.getUserByEmail(email);
    if (!user || !user.verificationCode || !user.verificationCodeExpiry) return false;
    if (new Date() > user.verificationCodeExpiry) return false;
    if (user.verificationCode !== code) return false;
    return true;
  }

  async getDiscountCode(code: string): Promise<DiscountCode | undefined> {
    const [discountCode] = await db
      .select()
      .from(discountCodes)
      .where(eq(discountCodes.code, code.toUpperCase()));
    return discountCode || undefined;
  }

  async getPaymentBySessionId(sessionId: string): Promise<Payment | undefined> {
    const [payment] = await db
      .select()
      .from(payments)
      .where(eq(payments.stripeSessionId, sessionId));
    return payment || undefined;
  }

  async createPayment(sessionId: string, userId: string, amount: number, minutes: number): Promise<Payment> {
    const [payment] = await db
      .insert(payments)
      .values({ stripeSessionId: sessionId, userId, amount, minutes })
      .returning();
    return payment;
  }

  async getAllDiscountCodes(): Promise<DiscountCode[]> {
    return db.select().from(discountCodes).orderBy(desc(discountCodes.createdAt));
  }

  async createDiscountCode(code: string, discountValue: number, startDate: Date, endDate: Date, createdBy?: string): Promise<DiscountCode> {
    const [discountCode] = await db
      .insert(discountCodes)
      .values({
        code: code.toUpperCase(),
        discountValue,
        startDate,
        endDate,
        createdBy,
      })
      .returning();
    return discountCode;
  }

  async deleteDiscountCode(id: string): Promise<void> {
    await db.delete(discountCodes).where(eq(discountCodes.id, id));
  }

  async incrementDiscountCodeUsage(id: string): Promise<void> {
    const [code] = await db.select().from(discountCodes).where(eq(discountCodes.id, id));
    if (code) {
      await db
        .update(discountCodes)
        .set({ usageCount: (code.usageCount || 0) + 1 })
        .where(eq(discountCodes.id, id));
    }
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateApiCosts(updates: Partial<SettingsApiCosts>): Promise<SettingsApiCosts> {
    const [existing] = await db.select().from(settingsApiCosts).limit(1);
    if (existing) {
      const [updated] = await db
        .update(settingsApiCosts)
        .set(updates)
        .where(eq(settingsApiCosts.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(settingsApiCosts)
        .values(updates as any)
        .returning();
      return created;
    }
  }

  async getFiscalStats(): Promise<{ totalRevenue: number; totalMinutesSold: number; totalUsers: number; paidUsers: number }> {
    const allPayments = await db.select().from(payments);
    const allUsers = await db.select().from(users);
    
    const totalRevenue = allPayments.reduce((sum, p) => sum + p.amount, 0);
    const totalMinutesSold = allPayments.reduce((sum, p) => sum + p.minutes, 0);
    const totalUsers = allUsers.length;
    const paidUsers = allUsers.filter(u => u.tier !== "free" || u.totalPurchases > 0).length;
    
    return { totalRevenue, totalMinutesSold, totalUsers, paidUsers };
  }

  async getAllAdsConfig(): Promise<AdsConfig[]> {
    return db.select().from(adsConfig).orderBy(desc(adsConfig.createdAt));
  }

  async createAdsConfig(config: InsertAdsConfig): Promise<AdsConfig> {
    const [created] = await db.insert(adsConfig).values(config).returning();
    return created;
  }

  async updateAdsConfig(id: string, updates: Partial<AdsConfig>): Promise<AdsConfig | undefined> {
    const [updated] = await db
      .update(adsConfig)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(adsConfig.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteAdsConfig(id: string): Promise<void> {
    await db.delete(adsConfig).where(eq(adsConfig.id, id));
  }

  async createAdminLog(adminId: string, action: string, targetType?: string, targetId?: string, details?: string, ipAddress?: string): Promise<AdminLog> {
    const [log] = await db.insert(adminLogs).values({
      adminId,
      action,
      targetType,
      targetId,
      details,
      ipAddress,
    }).returning();
    return log;
  }

  async getAdminLogs(): Promise<AdminLog[]> {
    return db.select().from(adminLogs).orderBy(desc(adminLogs.createdAt)).limit(500);
  }

  async createInvoiceRecord(data: { userId: string; paymentId: string; amount: number; minutes: number; apiCost: number; profit: number; vatAmount: number; taxAmount: number; discountAmount: number; discountCodeId?: string; tier: string }): Promise<InvoiceRecord> {
    const currentFiscalYear = await this.getCurrentFiscalYear();
    const [record] = await db.insert(invoiceRecords).values({
      ...data,
      fiscalYearId: currentFiscalYear?.id,
    }).returning();
    return record;
  }

  async getInvoiceRecords(): Promise<InvoiceRecord[]> {
    return db.select().from(invoiceRecords).orderBy(desc(invoiceRecords.createdAt));
  }

  async getFiscalYears(): Promise<FiscalYear[]> {
    return db.select().from(fiscalYears).orderBy(desc(fiscalYears.yearNumber));
  }

  async getCurrentFiscalYear(): Promise<FiscalYear | undefined> {
    const now = new Date();
    const [current] = await db
      .select()
      .from(fiscalYears)
      .where(and(
        lte(fiscalYears.startDate, now),
        gte(fiscalYears.endDate, now)
      ));
    return current || undefined;
  }

  async createOrUpdateFiscalYear(paymentAmount: number, taxAmount: number, vatAmount: number): Promise<FiscalYear> {
    const now = new Date();
    let current = await this.getCurrentFiscalYear();
    
    if (!current) {
      const allYears = await this.getFiscalYears();
      const nextYearNumber = allYears.length > 0 ? Math.max(...allYears.map(y => y.yearNumber)) + 1 : 1;
      const startDate = new Date();
      const endDate = new Date(startDate);
      endDate.setFullYear(endDate.getFullYear() + 1);
      
      const [created] = await db.insert(fiscalYears).values({
        yearNumber: nextYearNumber,
        startDate,
        endDate,
        totalPayments: paymentAmount,
        totalTax: taxAmount,
        totalVat: vatAmount,
        vatActive: false,
      }).returning();
      return created;
    }
    
    const newTotalPayments = current.totalPayments + paymentAmount;
    const newTotalTax = current.totalTax + taxAmount;
    const newTotalVat = current.totalVat + vatAmount;
    const vatActive = newTotalPayments > 30000;
    
    const [updated] = await db
      .update(fiscalYears)
      .set({
        totalPayments: newTotalPayments,
        totalTax: newTotalTax,
        totalVat: newTotalVat,
        vatActive,
      })
      .where(eq(fiscalYears.id, current.id))
      .returning();
    return updated;
  }

  async markFiscalYearPaid(id: string): Promise<FiscalYear | undefined> {
    const [updated] = await db
      .update(fiscalYears)
      .set({ isPaid: true, paidAt: new Date() })
      .where(eq(fiscalYears.id, id))
      .returning();
    return updated || undefined;
  }

  async logDiscountCodeUsage(discountCodeId: string, userId: string, paymentId: string, discountValue: number, tier: string): Promise<DiscountCodeUsage> {
    const [usage] = await db.insert(discountCodeUsage).values({
      discountCodeId,
      userId,
      paymentId,
      discountValue,
      tier,
    }).returning();
    return usage;
  }

  async getSubtitleByVideoAndLanguage(videoId: string, language: string): Promise<Subtitle | undefined> {
    const [subtitle] = await db
      .select()
      .from(subtitles)
      .where(and(eq(subtitles.videoId, videoId), eq(subtitles.language, language)));
    return subtitle || undefined;
  }

  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  async createUserNotification(data: { userId: string; title: string; message: string; type: string; sentBy?: string }): Promise<any> {
    const { userNotifications } = await import("@shared/schema");
    const [notification] = await db.insert(userNotifications).values({
      userId: data.userId,
      title: data.title,
      message: data.message,
      type: data.type,
      sentBy: data.sentBy,
    }).returning();
    return notification;
  }

  async getUserNotifications(userId: string): Promise<any[]> {
    const { userNotifications } = await import("@shared/schema");
    const notifications = await db
      .select()
      .from(userNotifications)
      .where(eq(userNotifications.userId, userId))
      .orderBy(desc(userNotifications.createdAt));
    return notifications;
  }

  async markNotificationAsRead(notificationId: string): Promise<void> {
    const { userNotifications } = await import("@shared/schema");
    await db
      .update(userNotifications)
      .set({ isRead: true })
      .where(eq(userNotifications.id, notificationId));
  }
}

export const storage = new DatabaseStorage();
