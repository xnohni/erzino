import { 
  Zap, 
  Globe, 
  Subtitles, 
  Clock, 
  Shield, 
  Download,
  GraduationCap,
  Users,
  Sparkles
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Zap,
    title: "Smart Sync Technology",
    description: "AI-powered synchronization ensures subtitles align perfectly with speech, creating a seamless viewing experience.",
    gradient: "from-primary to-primary/50",
  },
  {
    icon: Globe,
    title: "200+ Languages",
    description: "Translate your videos into over 200 languages including Spanish, French, German, Chinese, Japanese, Arabic, and many more.",
    gradient: "from-secondary to-secondary/50",
  },
  {
    icon: Subtitles,
    title: "Custom Caption Styling",
    description: "Personalize font size, color, background, and position. Make your subtitles match your brand perfectly.",
    gradient: "from-primary to-secondary",
  },
  {
    icon: Clock,
    title: "Fast Processing",
    description: "Advanced AI pipeline processes your videos quickly without compromising on accuracy or quality.",
    gradient: "from-secondary to-primary",
  },
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your content is processed securely with GDPR compliance. Audio files are deleted immediately after processing.",
    gradient: "from-primary to-primary/50",
  },
  {
    icon: Download,
    title: "Export Options",
    description: "Download your translated subtitles in .SRT or .VTT format for use anywhere.",
    gradient: "from-secondary to-secondary/50",
  },
];

const userTypes = [
  {
    icon: Users,
    title: "Content Creators",
    description: "Expand your global audience with professional multilingual subtitles.",
  },
  {
    icon: GraduationCap,
    title: "Students",
    description: "Get 17% off with verified academic email. Perfect for research and learning.",
  },
  {
    icon: Sparkles,
    title: "Educators",
    description: "Make your lectures accessible to diverse learners worldwide.",
  },
];

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-muted/30 to-transparent" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-display-sm md:text-display">
            Powerful Features for{" "}
            <span className="gradient-text">Everyone</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to translate and subtitle your video content with professional-grade accuracy.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card
              key={feature.title}
              className="group hover-elevate transition-all duration-300"
              data-testid={`card-feature-${index}`}
            >
              <CardContent className="p-6 space-y-4">
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.gradient} flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow`}>
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-20 pt-20 border-t border-border">
          <div className="text-center space-y-4 mb-12">
            <h3 className="text-display-sm">Built for Every User</h3>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Whether you're a creator, student, or educator, Erzino has the right plan for you.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {userTypes.map((type, index) => (
              <div
                key={type.title}
                className="text-center space-y-4 p-6"
                data-testid={`card-user-type-${index}`}
              >
                <div className="w-16 h-16 mx-auto rounded-full bg-muted flex items-center justify-center">
                  <type.icon className="w-8 h-8 text-primary" />
                </div>
                <h4 className="text-lg font-semibold">{type.title}</h4>
                <p className="text-muted-foreground">{type.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
