import { Play, Sparkles, ArrowRight, Globe, Subtitles, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface HeroSectionProps {
  onGetStarted: () => void;
}

export function HeroSection({ onGetStarted }: HeroSectionProps) {
  const scrollToPricing = () => {
    const element = document.querySelector("#pricing");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      <div className="absolute inset-0 bg-hero-gradient" />
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-secondary/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "1s" }} />
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="text-center space-y-8 animate-fade-up">
          <Badge variant="secondary" className="px-4 py-1.5 text-sm font-medium">
            <Sparkles className="w-3.5 h-3.5 mr-1.5" />
            AI-Powered Video Translation
          </Badge>

          <h1 className="text-hero-sm md:text-hero max-w-4xl mx-auto">
            Transform Your Videos with{" "}
            <span className="gradient-text">Smart Sync</span>{" "}
            Subtitles
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Professional AI translations for YouTube, Vimeo, and Dailymotion content. 
            Perfectly synchronized captions that enhance accessibility and expand your global reach.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button
              size="lg"
              onClick={onGetStarted}
              className="px-8 py-6 text-lg font-semibold animate-pulse-glow"
              data-testid="button-hero-get-started"
            >
              <Play className="w-5 h-5 mr-2 fill-current" />
              Start Translating Free
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={scrollToPricing}
              className="px-8 py-6 text-lg font-semibold backdrop-blur-sm"
              data-testid="button-hero-view-pricing"
            >
              View Pricing
            </Button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 pt-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              <span>30 Minutes Free</span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-secondary" />
              <span>200+ Languages</span>
            </div>
            <div className="flex items-center gap-2">
              <Subtitles className="w-4 h-4 text-primary" />
              <span>No Credit Card Required</span>
            </div>
          </div>
        </div>

        <div className="relative mt-16 md:mt-24">
          <div className="relative max-w-5xl mx-auto">
            <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 via-secondary/20 to-primary/20 rounded-2xl blur-xl opacity-50" />
            <div className="relative glass rounded-xl overflow-hidden shadow-2xl">
              <div className="bg-card/90 backdrop-blur-xl">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-destructive/80" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                    <div className="w-3 h-3 rounded-full bg-green-500/80" />
                  </div>
                  <div className="flex-1 text-center">
                    <span className="text-xs text-muted-foreground">Erzino Video Translator</span>
                  </div>
                </div>
                <div className="aspect-video bg-gradient-to-br from-muted/50 to-muted flex items-center justify-center relative">
                  <div className="absolute inset-0 flex items-end justify-center pb-16">
                    <div className="glass rounded-lg px-6 py-3 max-w-lg text-center">
                      <p className="text-lg font-medium">
                        "Welcome to the future of video translation..."
                      </p>
                    </div>
                  </div>
                  <div className="relative z-10">
                    <div className="w-20 h-20 rounded-full bg-primary/20 backdrop-blur-sm flex items-center justify-center hover-elevate cursor-pointer transition-transform hover:scale-105">
                      <Play className="w-8 h-8 text-primary fill-primary ml-1" />
                    </div>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 flex items-center gap-4">
                    <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                      <div className="w-1/3 h-full bg-primary rounded-full" />
                    </div>
                    <span className="text-xs text-muted-foreground font-mono">2:34 / 7:21</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
