import { Link2, Languages, Sparkles, Download } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: Link2,
    title: "Paste Your Video URL",
    description: "Simply paste a link from YouTube, Vimeo, or Dailymotion. We support videos of any length.",
  },
  {
    number: "02",
    icon: Languages,
    title: "Choose Your Language",
    description: "Select from 200+ languages for translation. Our AI ensures contextually accurate translations.",
  },
  {
    number: "03",
    icon: Sparkles,
    title: "Smart Sync Magic",
    description: "Our AI transcribes, translates, and synchronizes subtitles perfectly with the speech timing.",
  },
  {
    number: "04",
    icon: Download,
    title: "Watch & Download",
    description: "Preview your translated video instantly. Download subtitles in SRT or VTT format.",
  },
];

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-display-sm md:text-display">
            How <span className="gradient-text">Erzino</span> Works
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Four simple steps to transform your videos with professional translations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div
              key={step.number}
              className="relative group"
              data-testid={`step-${step.number}`}
            >
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-1/2 w-full h-0.5 bg-gradient-to-r from-primary/50 to-secondary/50 z-0" />
              )}
              
              <div className="relative z-10 flex flex-col items-center text-center space-y-4">
                <div className="relative">
                  <div className="absolute -inset-4 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-full blur-lg opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative w-24 h-24 rounded-full bg-card border-2 border-primary/30 flex items-center justify-center group-hover:border-primary transition-colors">
                    <step.icon className="w-10 h-10 text-primary" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                    {step.number}
                  </div>
                </div>
                
                <h3 className="text-xl font-semibold">{step.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
