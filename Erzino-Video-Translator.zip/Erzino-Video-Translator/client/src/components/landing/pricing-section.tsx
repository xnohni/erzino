import { useState, useEffect } from "react";
import { Check, Sparkles, GraduationCap, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import type { UserTier } from "@shared/schema";

interface PricingSectionProps {
  onSelectTier: (tier: UserTier) => void;
}

const API_COST_PER_MINUTE = 0.00673;
const PROFIT_MARGIN = 0.26;

function calculatePrice(minutes: number, isStudent: boolean = false): number {
  const apiCost = minutes * API_COST_PER_MINUTE;
  const withProfit = apiCost * (1 + PROFIT_MARGIN);
  const discount = isStudent ? withProfit * 0.17 : 0;
  return Math.round((withProfit - discount) * 100) / 100;
}

export function PricingSection({ onSelectTier }: PricingSectionProps) {
  const [standardMinutes, setStandardMinutes] = useState(1000);
  const [studentMinutes, setStudentMinutes] = useState(1000);
  const [standardPrice, setStandardPrice] = useState(0);
  const [studentPrice, setStudentPrice] = useState(0);

  useEffect(() => {
    setStandardPrice(calculatePrice(standardMinutes));
  }, [standardMinutes]);

  useEffect(() => {
    setStudentPrice(calculatePrice(studentMinutes, true));
  }, [studentMinutes]);

  const formatMinutes = (mins: number) => {
    if (mins >= 60) {
      const hours = Math.floor(mins / 60);
      const remaining = mins % 60;
      return remaining > 0 ? `${hours}h ${remaining}m` : `${hours} hours`;
    }
    return `${mins} minutes`;
  };

  const tiers = [
    {
      id: "free" as UserTier,
      name: "Free",
      description: "Perfect for trying out Erzino",
      price: 0,
      minutes: 30,
      icon: Zap,
      features: [
        "30 minutes free translation",
        "All 200+ languages",
        "Smart Sync subtitles",
        "Basic video player",
        "Ad-supported experience",
      ],
      excluded: [
        "Caption styling",
        "Video history",
        "Shared links",
        "Subtitle downloads",
      ],
      buttonText: "Get Started Free",
      popular: false,
    },
    {
      id: "standard" as UserTier,
      name: "Standard",
      description: "For content creators and professionals",
      price: standardPrice,
      minutes: standardMinutes,
      icon: Sparkles,
      features: [
        "Flexible minutes packages",
        "All 200+ languages",
        "Smart Sync subtitles",
        "Full caption styling",
        "Video history",
        "Shared links",
        "SRT/VTT downloads",
        "Ad-free experience",
        "Priority processing",
      ],
      excluded: [],
      buttonText: "Choose Standard",
      popular: true,
      hasSlider: true,
      setMinutes: setStandardMinutes,
    },
    {
      id: "student" as UserTier,
      name: "Student",
      description: "17% discount with verified .edu email",
      price: studentPrice,
      minutes: studentMinutes,
      icon: GraduationCap,
      features: [
        "17% student discount",
        "Flexible minutes packages",
        "All 200+ languages",
        "Smart Sync subtitles",
        "Full caption styling",
        "Video history",
        "Shared links",
        "SRT/VTT downloads",
        "Ad-free experience",
      ],
      excluded: [],
      buttonText: "Verify Student Email",
      popular: false,
      hasSlider: true,
      setMinutes: setStudentMinutes,
      isStudent: true,
    },
  ];

  return (
    <section id="pricing" className="py-20 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-muted/30 via-transparent to-muted/30" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="px-4 py-1.5">
            Simple, Transparent Pricing
          </Badge>
          <h2 className="text-display-sm md:text-display">
            Choose Your <span className="gradient-text">Perfect Plan</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Pay only for what you need. No subscriptions, no hidden fees.
            Buy minutes and use them whenever you want.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {tiers.map((tier) => (
            <Card
              key={tier.id}
              className={`relative flex flex-col ${
                tier.popular
                  ? "border-primary shadow-lg shadow-primary/10"
                  : ""
              }`}
              data-testid={`card-pricing-${tier.id}`}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="px-4 py-1 bg-primary text-primary-foreground">
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-2">
                <div className="w-14 h-14 mx-auto rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-4">
                  <tier.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-2xl font-bold">{tier.name}</h3>
                <p className="text-sm text-muted-foreground">{tier.description}</p>
              </CardHeader>

              <CardContent className="flex-1 space-y-6">
                {tier.hasSlider ? (
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-4xl font-bold">
                        ${tier.price.toFixed(2)}
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">
                        for {formatMinutes(tier.minutes)}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        ${(tier.price / tier.minutes).toFixed(4)}/minute
                      </div>
                    </div>
                    <div className="space-y-2 px-2">
                      <Slider
                        value={[tier.minutes]}
                        onValueChange={([value]) => tier.setMinutes?.(value)}
                        min={350}
                        max={17000}
                        step={50}
                        className="w-full"
                        data-testid={`slider-minutes-${tier.id}`}
                      />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>350 min</span>
                        <span>17,000 min</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="text-4xl font-bold">
                      {tier.price === 0 ? "Free" : `$${tier.price}`}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      {tier.minutes} minutes included
                    </div>
                  </div>
                )}

                <ul className="space-y-3">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                  {tier.excluded.map((feature) => (
                    <li key={feature} className="flex items-start gap-3 opacity-50">
                      <span className="w-5 h-5 shrink-0 mt-0.5 text-center">-</span>
                      <span className="text-sm line-through">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Button
                  className="w-full"
                  variant={tier.popular ? "default" : "outline"}
                  size="lg"
                  onClick={() => onSelectTier(tier.id)}
                  data-testid={`button-select-${tier.id}`}
                >
                  {tier.buttonText}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>
            All prices are in USD. VAT and taxes may apply based on your location.
          </p>
          <p className="mt-2">
            Student verification requires a valid academic email address (.edu or equivalent).
          </p>
        </div>
      </div>
    </section>
  );
}
