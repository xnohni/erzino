import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Play, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./theme-toggle";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface NavigationProps {
  onLoginClick: () => void;
  onSignupClick: () => void;
  isAuthenticated?: boolean;
}

export function Navigation({ onLoginClick, onSignupClick, isAuthenticated }: NavigationProps) {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { label: "Features", href: "#features" },
    { label: "Pricing", href: "#pricing" },
    { label: "How it Works", href: "#how-it-works" },
  ];

  const handleNavClick = (href: string) => {
    if (href.startsWith("#")) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-strong">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          <Link href="/" className="flex items-center gap-2 group" data-testid="link-home">
            <div className="relative w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg group-hover:shadow-primary/25 transition-shadow">
              <Play className="w-4 h-4 text-white fill-white ml-0.5" />
              <Zap className="absolute -top-1 -right-1 w-3 h-3 text-secondary" />
            </div>
            <span className="text-xl font-bold tracking-tight gradient-text">
              Erzino
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.href}
                onClick={() => handleNavClick(item.href)}
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors rounded-lg hover-elevate"
                data-testid={`link-nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            
            <div className="hidden sm:flex items-center gap-2">
              {!isAuthenticated ? (
                <>
                  <Button
                    variant="ghost"
                    onClick={onLoginClick}
                    data-testid="button-login"
                  >
                    Log In
                  </Button>
                  <Button
                    onClick={onSignupClick}
                    data-testid="button-signup"
                  >
                    Get Started Free
                  </Button>
                </>
              ) : (
                <Link href="/dashboard">
                  <Button data-testid="button-dashboard">
                    Dashboard
                  </Button>
                </Link>
              )}
            </div>

            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
                  {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <nav className="flex flex-col gap-4 mt-8">
                  {navItems.map((item) => (
                    <button
                      key={item.href}
                      onClick={() => handleNavClick(item.href)}
                      className="px-4 py-3 text-lg font-medium text-left hover:bg-accent rounded-lg transition-colors"
                      data-testid={`link-mobile-nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      {item.label}
                    </button>
                  ))}
                  <div className="border-t pt-4 mt-4 flex flex-col gap-2">
                    {!isAuthenticated ? (
                      <>
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => {
                            onLoginClick();
                            setMobileMenuOpen(false);
                          }}
                          data-testid="button-mobile-login"
                        >
                          Log In
                        </Button>
                        <Button
                          className="w-full"
                          onClick={() => {
                            onSignupClick();
                            setMobileMenuOpen(false);
                          }}
                          data-testid="button-mobile-signup"
                        >
                          Get Started Free
                        </Button>
                      </>
                    ) : (
                      <Link href="/dashboard">
                        <Button className="w-full" data-testid="button-mobile-dashboard">
                          Dashboard
                        </Button>
                      </Link>
                    )}
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
