import { useState } from "react";
import { Type, Palette, Move, Download, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface CaptionStylingPanelProps {
  settings: {
    fontSize: number;
    fontColor: string;
    backgroundColor: string;
    fontFamily: string;
    position: string;
  };
  onSettingsChange: (settings: CaptionStylingPanelProps["settings"]) => void;
  onSave?: () => void;
  onDownloadSRT?: () => void;
  onDownloadVTT?: () => void;
  isPaidUser?: boolean;
}

const fontFamilies = [
  { value: "Outfit", label: "Outfit" },
  { value: "Arial", label: "Arial" },
  { value: "Roboto", label: "Roboto" },
  { value: "Open Sans", label: "Open Sans" },
  { value: "Lato", label: "Lato" },
];

const colorPresets = [
  { value: "#ffffff", label: "White" },
  { value: "#ffff00", label: "Yellow" },
  { value: "#00ff00", label: "Green" },
  { value: "#00ffff", label: "Cyan" },
  { value: "#ff00ff", label: "Magenta" },
];

const bgPresets = [
  { value: "rgba(0,0,0,0.7)", label: "Dark" },
  { value: "rgba(0,0,0,0.9)", label: "Darker" },
  { value: "rgba(0,0,0,0.5)", label: "Semi" },
  { value: "rgba(0,0,0,0)", label: "None" },
];

export function CaptionStylingPanel({
  settings,
  onSettingsChange,
  onSave,
  onDownloadSRT,
  onDownloadVTT,
  isPaidUser = false,
}: CaptionStylingPanelProps) {
  const updateSetting = <K extends keyof typeof settings>(
    key: K,
    value: typeof settings[K]
  ) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  return (
    <Card className="h-full" data-testid="caption-styling-panel">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg flex items-center gap-2">
          <Type className="w-5 h-5" />
          Caption Styling
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <Label className="flex items-center gap-2">
            <Type className="w-4 h-4" />
            Font Size: {settings.fontSize}px
          </Label>
          <Slider
            value={[settings.fontSize]}
            onValueChange={([value]) => updateSetting("fontSize", value)}
            min={12}
            max={32}
            step={1}
            disabled={!isPaidUser}
            data-testid="slider-font-size"
          />
        </div>

        <div className="space-y-3">
          <Label>Font Family</Label>
          <Select
            value={settings.fontFamily}
            onValueChange={(value) => updateSetting("fontFamily", value)}
            disabled={!isPaidUser}
          >
            <SelectTrigger data-testid="select-font-family">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {fontFamilies.map((font) => (
                <SelectItem key={font.value} value={font.value}>
                  {font.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <Label className="flex items-center gap-2">
            <Palette className="w-4 h-4" />
            Font Color
          </Label>
          <div className="flex flex-wrap gap-2">
            {colorPresets.map((color) => (
              <button
                key={color.value}
                onClick={() => updateSetting("fontColor", color.value)}
                disabled={!isPaidUser}
                className={`w-8 h-8 rounded-md border-2 transition-all ${
                  settings.fontColor === color.value
                    ? "border-primary scale-110"
                    : "border-transparent"
                } ${!isPaidUser ? "opacity-50 cursor-not-allowed" : ""}`}
                style={{ backgroundColor: color.value }}
                title={color.label}
                data-testid={`button-color-${color.label.toLowerCase()}`}
              />
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <Label>Background</Label>
          <div className="flex flex-wrap gap-2">
            {bgPresets.map((bg) => (
              <button
                key={bg.value}
                onClick={() => updateSetting("backgroundColor", bg.value)}
                disabled={!isPaidUser}
                className={`px-3 py-1.5 rounded-md text-xs font-medium border transition-all ${
                  settings.backgroundColor === bg.value
                    ? "border-primary bg-primary/10"
                    : "border-border"
                } ${!isPaidUser ? "opacity-50 cursor-not-allowed" : ""}`}
                data-testid={`button-bg-${bg.label.toLowerCase()}`}
              >
                {bg.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <Label className="flex items-center gap-2">
            <Move className="w-4 h-4" />
            Position
          </Label>
          <Select
            value={settings.position}
            onValueChange={(value) => updateSetting("position", value)}
            disabled={!isPaidUser}
          >
            <SelectTrigger data-testid="select-position">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="bottom">Bottom</SelectItem>
              <SelectItem value="top">Top</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {!isPaidUser && (
          <p className="text-xs text-muted-foreground text-center p-3 bg-muted rounded-lg">
            Upgrade to a paid plan to customize captions
          </p>
        )}

        <div className="pt-4 space-y-3">
          {isPaidUser && (
            <Button
              onClick={onSave}
              className="w-full"
              data-testid="button-save-settings"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Settings
            </Button>
          )}

          {isPaidUser && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={onDownloadSRT}
                className="flex-1"
                data-testid="button-download-srt"
              >
                <Download className="w-4 h-4 mr-2" />
                .SRT
              </Button>
              <Button
                variant="outline"
                onClick={onDownloadVTT}
                className="flex-1"
                data-testid="button-download-vtt"
              >
                <Download className="w-4 h-4 mr-2" />
                .VTT
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
