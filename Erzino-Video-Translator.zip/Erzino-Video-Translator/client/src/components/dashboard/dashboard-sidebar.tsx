import { Link, useLocation } from "wouter";
import {
  Play,
  Zap,
  Home,
  Clock,
  Settings,
  Share2,
  LogOut,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  HelpCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { MinutesDisplay } from "./minutes-display";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import type { UserTier } from "@shared/schema";

interface DashboardSidebarProps {
  user: {
    name: string;
    email: string;
    tier: UserTier;
    minutesRemaining: number;
  };
  onLogout: () => void;
  onBuyMore: () => void;
}

const menuItems = [
  { icon: Home, label: "Dashboard", href: "/dashboard" },
  { icon: Clock, label: "History", href: "/dashboard/history" },
  { icon: Share2, label: "Shared Links", href: "/dashboard/shared" },
  { icon: CreditCard, label: "Billing", href: "/dashboard/billing" },
  { icon: Settings, label: "Settings", href: "/dashboard/settings" },
];

export function DashboardSidebar({ user, onLogout, onBuyMore }: DashboardSidebarProps) {
  const [location] = useLocation();
  const { state } = useSidebar();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-4">
        <Link href="/" className="flex items-center gap-2" data-testid="link-sidebar-home">
          <div className="relative w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg shrink-0">
            <Play className="w-4 h-4 text-white fill-white ml-0.5" />
            <Zap className="absolute -top-1 -right-1 w-3 h-3 text-secondary" />
          </div>
          {state === "expanded" && (
            <span className="text-xl font-bold tracking-tight gradient-text">
              Erzino
            </span>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.href}
                    tooltip={item.label}
                  >
                    <Link href={item.href} data-testid={`link-${item.label.toLowerCase()}`}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {state === "expanded" && (
          <SidebarGroup>
            <SidebarGroupLabel>Usage</SidebarGroupLabel>
            <SidebarGroupContent className="px-2">
              <MinutesDisplay
                minutesRemaining={user.minutesRemaining}
                tier={user.tier}
                onBuyMore={onBuyMore}
              />
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4 space-y-4">
        {state === "expanded" && (
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-semibold shrink-0">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
            </div>
          </div>
        )}

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <SidebarMenuButton asChild tooltip="Help">
            <button>
              <HelpCircle className="w-4 h-4" />
              {state === "expanded" && <span>Help</span>}
            </button>
          </SidebarMenuButton>
          <SidebarMenuButton asChild tooltip="Logout" onClick={onLogout}>
            <button data-testid="button-logout">
              <LogOut className="w-4 h-4" />
              {state === "expanded" && <span>Logout</span>}
            </button>
          </SidebarMenuButton>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
