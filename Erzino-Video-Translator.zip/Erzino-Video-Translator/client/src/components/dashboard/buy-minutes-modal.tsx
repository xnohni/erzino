import { useState, useEffect } from "react";
import { Loader2, CreditCard, Zap, Check, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import type { UserTier } from "@shared/schema";

interface BuyMinutesModalProps {
  isOpen: boolean;
  onClose: () => void;
  tier: UserTier;
  totalPurchases?: number;
  onPurchase: (minutes: number, price: number) => void;
}

const API_COST_PER_MINUTE = 0.00673;
const PROFIT_MARGIN = 0.26;
const STUDENT_DISCOUNT = 0.17;

export function BuyMinutesModal({
  isOpen,
  onClose,
  tier,
  totalPurchases = 0,
  onPurchase,
}: BuyMinutesModalProps) {
  const [minutes, setMinutes] = useState(1000);
  const [price, setPrice] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [discountCode, setDiscountCode] = useState("");
  const [discountError, setDiscountError] = useState<string | null>(null);
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);

  const isStudent = tier === "student";

  useEffect(() => {
    const apiCost = minutes * API_COST_PER_MINUTE;
    const withProfit = apiCost * (1 + PROFIT_MARGIN);
    const studentDiscount = isStudent ? withProfit * STUDENT_DISCOUNT : 0;
    const basePrice = withProfit - studentDiscount;
    const codeDiscount = appliedDiscount > 0 ? basePrice * (appliedDiscount / 100) : 0;
    setPrice(Math.round((basePrice - codeDiscount) * 100) / 100);
  }, [minutes, isStudent, appliedDiscount]);

  const handleApplyDiscount = async () => {
    if (!discountCode.trim()) return;
    
    try {
      const res = await apiRequest("POST", "/api/discount-codes/validate", { 
        code: discountCode 
      });
      const data = await res.json();
      if (data.valid) {
        setAppliedDiscount(data.discountValue);
        setDiscountError(null);
      } else {
        setDiscountError("This discount code has expired or is invalid.");
        setAppliedDiscount(0);
      }
    } catch {
      setDiscountError("This discount code has expired or is invalid.");
      setAppliedDiscount(0);
    }
  };

  const handlePurchase = async () => {
    setIsProcessing(true);
    
    try {
      const res = await apiRequest("POST", "/api/checkout/minutes", { 
        minutes,
        discountCode: appliedDiscount > 0 ? discountCode : undefined
      });
      const data = await res.json();
      
      if (data.url) {
        window.location.href = data.url;
      } else {
        onPurchase(minutes, price);
        onClose();
      }
    } catch (error) {
      console.error("Checkout error:", error);
    }
    
    setIsProcessing(false);
  };

  const formatMinutes = (mins: number) => {
    if (mins >= 60) {
      const hours = Math.floor(mins / 60);
      const remaining = mins % 60;
      return remaining > 0 ? `${hours}h ${remaining}m` : `${hours} hours`;
    }
    return `${mins} minutes`;
  };

  const pricePerMinute = price / minutes;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Buy More Minutes
          </DialogTitle>
          <DialogDescription>
            Select the number of minutes you want to purchase
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {isStudent && (
            <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-lg">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">17% Student Discount Applied</span>
            </div>
          )}

          <div className="text-center space-y-2">
            <div className="text-5xl font-bold gradient-text">
              ${price.toFixed(2)}
            </div>
            <div className="text-lg text-muted-foreground">
              {formatMinutes(minutes)}
            </div>
            <div className="text-sm text-muted-foreground">
              ${pricePerMinute.toFixed(4)} per minute
            </div>
          </div>

          <div className="space-y-4 px-2">
            <Slider
              value={[minutes]}
              onValueChange={([value]) => setMinutes(value)}
              min={350}
              max={17000}
              step={50}
              className="w-full"
              data-testid="slider-buy-minutes"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>350 min (~6 hours)</span>
              <span>17,000 min (~283 hours)</span>
            </div>
          </div>

          <div className="space-y-3 pt-4">
            <div className="flex items-center gap-2 text-sm">
              <Check className="w-4 h-4 text-green-500" />
              <span>Minutes never expire</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Check className="w-4 h-4 text-green-500" />
              <span>Use across unlimited videos</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Check className="w-4 h-4 text-green-500" />
              <span>Secure payment via Stripe</span>
            </div>
          </div>

          {tier !== "free" && totalPurchases >= 1 && (
            <div className="space-y-2">
              <Label htmlFor="discount-code" className="flex items-center gap-2">
                <Tag className="w-4 h-4" />
                Discount Code
              </Label>
              <div className="flex gap-2">
                <Input
                  id="discount-code"
                  placeholder="Enter code"
                  value={discountCode}
                  onChange={(e) => setDiscountCode(e.target.value.toUpperCase())}
                  className="flex-1"
                  data-testid="input-discount-code"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleApplyDiscount}
                  disabled={!discountCode.trim()}
                  data-testid="button-apply-discount"
                >
                  Apply
                </Button>
              </div>
              {discountError && (
                <p className="text-sm text-destructive">{discountError}</p>
              )}
              {appliedDiscount > 0 && (
                <p className="text-sm text-green-500">
                  {appliedDiscount}% discount applied
                </p>
              )}
            </div>
          )}
          
          {tier !== "free" && totalPurchases === 0 && (
            <div className="p-3 bg-muted/50 rounded-md text-sm text-muted-foreground text-center">
              Discount codes available from your 2nd purchase onwards
            </div>
          )}

          <Button
            onClick={handlePurchase}
            disabled={isProcessing}
            className="w-full"
            size="lg"
            data-testid="button-confirm-purchase"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                Processing...
              </>
            ) : (
              <>
                <CreditCard className="w-4 h-4 mr-2" />
                Pay ${price.toFixed(2)}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
