import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tag, Copy, Check, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface DiscountCode {
  id: string;
  code: string;
  discountValue: number;
  startDate: string;
  endDate: string;
}

interface DiscountBannerProps {
  tier: string;
  totalPurchases: number;
}

export function DiscountBanner({ tier, totalPurchases }: DiscountBannerProps) {
  const { toast } = useToast();
  const [dismissed, setDismissed] = useState(false);
  const [copied, setCopied] = useState(false);

  const { data: discountCodes } = useQuery<DiscountCode[]>({
    queryKey: ["/api/discount-codes/active"],
    enabled: tier !== "free" && totalPurchases >= 1,
  });

  if (dismissed) return null;
  if (tier === "free") return null;
  if (totalPurchases < 1) return null;
  if (!discountCodes || discountCodes.length === 0) return null;

  const activeCode = discountCodes[0];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(activeCode.code);
      setCopied(true);
      toast({
        title: "Code Copied",
        description: `Discount code ${activeCode.code} copied to clipboard.`,
      });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({
        title: "Copy Failed",
        description: "Please manually copy the code.",
        variant: "destructive",
      });
    }
  };

  return (
    <Alert className="relative bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-primary/20" data-testid="discount-banner">
      <Tag className="h-4 w-4" />
      <AlertDescription className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-sm">Special offer:</span>
          <Badge variant="secondary" className="font-mono text-sm">
            {activeCode.code}
          </Badge>
          <span className="text-sm font-semibold text-primary">
            {activeCode.discountValue}% off
          </span>
          <span className="text-xs text-muted-foreground">
            your next purchase
          </span>
        </div>
        <div className="flex items-center gap-1">
          <Button 
            size="sm" 
            variant="outline" 
            onClick={handleCopy}
            className="h-7"
            data-testid="button-copy-discount"
          >
            {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
            {copied ? "Copied" : "Copy"}
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
            onClick={() => setDismissed(true)}
            data-testid="button-dismiss-discount"
          >
            <X className="w-3 h-3" />
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
}
