import { useState } from "react";
import { Copy, Check, Lock, Share2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface ShareVideoDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  videoId: string;
  videoTitle: string;
}

export function ShareVideoDialog({
  open,
  onOpenChange,
  videoId,
  videoTitle,
}: ShareVideoDialogProps) {
  const [isPasswordProtected, setIsPasswordProtected] = useState(false);
  const [password, setPassword] = useState("");
  const [shareLink, setShareLink] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const handleCreateLink = async () => {
    setIsCreating(true);
    
    try {
      const sessionId = localStorage.getItem("sessionId");
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (sessionId) {
        headers["Authorization"] = `Bearer ${sessionId}`;
      }
      
      const response = await fetch("/api/shared-links", {
        method: "POST",
        headers,
        body: JSON.stringify({
          videoId,
          password: isPasswordProtected ? password : undefined,
        }),
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to create share link");
      }
      
      const data = await response.json();
      const link = `${window.location.origin}/shared/${data.shareCode}`;
      setShareLink(link);
      
      toast({
        title: "Share link created",
        description: "Your video sharing link is ready!",
      });
    } catch (err) {
      console.error("Error creating share link:", err);
      toast({
        title: "Error",
        description: "Failed to create share link. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const handleCopyLink = async () => {
    if (!shareLink) return;
    
    try {
      await navigator.clipboard.writeText(shareLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Copied!",
        description: "Share link copied to clipboard.",
      });
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  const handleClose = () => {
    setShareLink(null);
    setPassword("");
    setIsPasswordProtected(false);
    setCopied(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent data-testid="dialog-share-video">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Share Video
          </DialogTitle>
          <DialogDescription>
            Create a shareable link for "{videoTitle}"
          </DialogDescription>
        </DialogHeader>

        {!shareLink ? (
          <div className="space-y-6 py-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Password Protection
                </Label>
                <p className="text-xs text-muted-foreground">
                  Require a password to view the video
                </p>
              </div>
              <Switch
                checked={isPasswordProtected}
                onCheckedChange={setIsPasswordProtected}
                data-testid="switch-password-protection"
              />
            </div>

            {isPasswordProtected && (
              <div className="space-y-2">
                <Label htmlFor="share-password">Password</Label>
                <Input
                  id="share-password"
                  type="password"
                  placeholder="Enter a password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  data-testid="input-share-password"
                />
              </div>
            )}

            <Button
              onClick={handleCreateLink}
              className="w-full"
              disabled={isCreating || (isPasswordProtected && !password)}
              data-testid="button-create-share-link"
            >
              {isCreating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  Creating Link...
                </>
              ) : (
                "Create Share Link"
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Your share link</Label>
              <div className="flex gap-2">
                <Input
                  value={shareLink}
                  readOnly
                  className="font-mono text-sm"
                  data-testid="input-share-link"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleCopyLink}
                  data-testid="button-copy-share-link"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-green-500" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>

            {isPasswordProtected && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  This link is password protected. Share the password separately.
                </p>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                onClick={handleClose}
                className="flex-1"
              >
                Close
              </Button>
              <Button
                onClick={() => {
                  setShareLink(null);
                  setPassword("");
                  setIsPasswordProtected(false);
                }}
                className="flex-1"
                data-testid="button-create-new-link"
              >
                Create New Link
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
