import { Clock, Plus, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import type { UserTier } from "@shared/schema";

interface MinutesDisplayProps {
  minutesRemaining: number;
  tier: UserTier;
  onBuyMore?: () => void;
}

export function MinutesDisplay({
  minutesRemaining,
  tier,
  onBuyMore,
}: MinutesDisplayProps) {
  const maxMinutes = tier === "free" ? 30 : 17000;
  const percentage = Math.min((minutesRemaining / maxMinutes) * 100, 100);
  const isLow = minutesRemaining < 10;

  const formatMinutes = (mins: number) => {
    if (mins >= 60) {
      const hours = Math.floor(mins / 60);
      const remaining = mins % 60;
      return remaining > 0 ? `${hours}h ${remaining}m` : `${hours}h`;
    }
    return `${mins}m`;
  };

  return (
    <div className="space-y-3" data-testid="minutes-display">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium">Minutes Left</span>
        </div>
        <Badge
          variant={tier === "free" ? "secondary" : "default"}
          className="capitalize"
        >
          {tier === "student" && <Zap className="w-3 h-3 mr-1" />}
          {tier}
        </Badge>
      </div>

      <div className="space-y-2">
        <div className="flex items-baseline justify-between">
          <span
            className={`text-2xl font-bold ${isLow ? "text-destructive" : ""}`}
            data-testid="text-minutes-remaining"
          >
            {formatMinutes(minutesRemaining)}
          </span>
          <span className="text-sm text-muted-foreground">
            / {formatMinutes(maxMinutes)}
          </span>
        </div>
        <Progress
          value={percentage}
          className={`h-2 ${isLow ? "[&>div]:bg-destructive" : ""}`}
          data-testid="progress-minutes"
        />
      </div>

      {isLow && (
        <p className="text-xs text-destructive">
          Running low on minutes! Consider purchasing more.
        </p>
      )}

      {tier !== "free" && onBuyMore && (
        <Button
          variant="outline"
          size="sm"
          onClick={onBuyMore}
          className="w-full"
          data-testid="button-buy-more"
        >
          <Plus className="w-4 h-4 mr-2" />
          Buy More Minutes
        </Button>
      )}

      {tier === "free" && onBuyMore && (
        <Button
          size="sm"
          onClick={onBuyMore}
          className="w-full"
          data-testid="button-upgrade"
        >
          Upgrade to Paid
        </Button>
      )}
    </div>
  );
}
