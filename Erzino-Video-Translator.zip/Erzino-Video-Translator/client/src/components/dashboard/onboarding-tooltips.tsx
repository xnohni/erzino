import { useState, useEffect } from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { X, ChevronRight, ChevronLeft } from "lucide-react";

interface OnboardingStep {
  target: string;
  title: string;
  description: string;
  position?: "top" | "bottom" | "left" | "right";
}

const onboardingSteps: OnboardingStep[] = [
  {
    target: "[data-testid='display-minutes-left']",
    title: "Your Minutes Balance",
    description: "Track your available translation minutes here. Each minute of video uses one minute from your balance.",
    position: "bottom",
  },
  {
    target: "[data-testid='video-url-input']",
    title: "Paste Video URL",
    description: "Enter a YouTube, Vimeo, or Dailymotion link to start translating. We support 200+ languages!",
    position: "top",
  },
  {
    target: "[data-testid='caption-styling-panel']",
    title: "Caption Styling",
    description: "Customize your subtitles with different fonts, colors, and positions. Available for paid users.",
    position: "left",
  },
  {
    target: "[data-testid='button-notifications']",
    title: "Notifications",
    description: "Stay updated with important messages and alerts from the platform.",
    position: "bottom",
  },
];

interface OnboardingTooltipsProps {
  onComplete: () => void;
}

export function OnboardingTooltips({ onComplete }: OnboardingTooltipsProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isOpen, setIsOpen] = useState(true);
  const [targetElement, setTargetElement] = useState<Element | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    
    const step = onboardingSteps[currentStep];
    const element = document.querySelector(step.target);
    setTargetElement(element);
    
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [currentStep, isOpen]);

  const handleNext = () => {
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    setIsOpen(false);
    localStorage.setItem("onboardingCompleted", "true");
    onComplete();
  };

  const handleSkip = () => {
    handleComplete();
  };

  if (!isOpen || !targetElement) return null;

  const step = onboardingSteps[currentStep];

  return (
    <Tooltip open={true}>
      <TooltipTrigger asChild>
        <div 
          className="fixed pointer-events-none"
          style={{
            top: targetElement.getBoundingClientRect().top,
            left: targetElement.getBoundingClientRect().left,
            width: targetElement.getBoundingClientRect().width,
            height: targetElement.getBoundingClientRect().height,
          }}
        />
      </TooltipTrigger>
      <TooltipContent 
        side={step.position || "bottom"} 
        className="glass-frosted p-4 max-w-xs z-[100]"
        data-testid="onboarding-tooltip"
      >
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-2">
            <h4 className="font-semibold text-sm">{step.title}</h4>
            <Button
              size="icon"
              variant="ghost"
              className="h-6 w-6 shrink-0"
              onClick={handleSkip}
              data-testid="button-skip-onboarding"
            >
              <X className="w-3 h-3" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">{step.description}</p>
          <div className="flex items-center justify-between pt-2">
            <div className="flex gap-1">
              {onboardingSteps.map((_, i) => (
                <div
                  key={i}
                  className={`w-1.5 h-1.5 rounded-full transition-colors ${
                    i === currentStep ? "bg-primary" : "bg-muted"
                  }`}
                />
              ))}
            </div>
            <div className="flex gap-1">
              {currentStep > 0 && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handlePrev}
                  className="h-7 px-2"
                  data-testid="button-prev-onboarding"
                >
                  <ChevronLeft className="w-3 h-3" />
                </Button>
              )}
              <Button
                size="sm"
                onClick={handleNext}
                className="h-7"
                data-testid="button-next-onboarding"
              >
                {currentStep === onboardingSteps.length - 1 ? "Done" : "Next"}
                {currentStep < onboardingSteps.length - 1 && (
                  <ChevronRight className="w-3 h-3 ml-1" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

export function useOnboarding() {
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    const completed = localStorage.getItem("onboardingCompleted");
    if (!completed) {
      const timer = setTimeout(() => setShowOnboarding(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  return {
    showOnboarding,
    completeOnboarding: () => setShowOnboarding(false),
  };
}
