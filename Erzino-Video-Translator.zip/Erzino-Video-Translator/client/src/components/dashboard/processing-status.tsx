import { Loader2, CheckCircle, AlertCircle, Mic, Languages, Sparkles, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

type ProcessingStep = "extracting" | "transcribing" | "translating" | "syncing" | "completed" | "failed";

interface ProcessingStatusProps {
  currentStep: ProcessingStep;
  progress: number;
  error?: string;
}

const steps: { id: ProcessingStep; label: string; icon: typeof Mic }[] = [
  { id: "extracting", label: "Extracting Audio", icon: Mic },
  { id: "transcribing", label: "Transcribing Speech", icon: FileText },
  { id: "translating", label: "Translating Text", icon: Languages },
  { id: "syncing", label: "Smart Sync", icon: Sparkles },
];

export function ProcessingStatus({
  currentStep,
  progress,
  error,
}: ProcessingStatusProps) {
  const getStepStatus = (stepId: ProcessingStep) => {
    const stepIndex = steps.findIndex((s) => s.id === stepId);
    const currentIndex = steps.findIndex((s) => s.id === currentStep);

    if (currentStep === "completed") return "completed";
    if (currentStep === "failed") {
      if (stepIndex <= currentIndex) return "failed";
      return "pending";
    }
    if (stepIndex < currentIndex) return "completed";
    if (stepIndex === currentIndex) return "active";
    return "pending";
  };

  return (
    <Card data-testid="processing-status">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg flex items-center gap-2">
          {currentStep === "completed" ? (
            <>
              <CheckCircle className="w-5 h-5 text-green-500" />
              Translation Complete
            </>
          ) : currentStep === "failed" ? (
            <>
              <AlertCircle className="w-5 h-5 text-destructive" />
              Processing Failed
            </>
          ) : (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Processing Video
            </>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Progress value={progress} className="h-2" />
          <p className="text-sm text-muted-foreground text-right">{progress}%</p>
        </div>

        <div className="space-y-3">
          {steps.map((step) => {
            const status = getStepStatus(step.id);
            const Icon = step.icon;

            return (
              <div
                key={step.id}
                className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  status === "active"
                    ? "bg-primary/10"
                    : status === "completed"
                    ? "bg-green-500/10"
                    : status === "failed"
                    ? "bg-destructive/10"
                    : "bg-muted/50"
                }`}
                data-testid={`processing-step-${step.id}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    status === "active"
                      ? "bg-primary text-primary-foreground"
                      : status === "completed"
                      ? "bg-green-500 text-white"
                      : status === "failed"
                      ? "bg-destructive text-destructive-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {status === "active" ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : status === "completed" ? (
                    <CheckCircle className="w-4 h-4" />
                  ) : status === "failed" ? (
                    <AlertCircle className="w-4 h-4" />
                  ) : (
                    <Icon className="w-4 h-4" />
                  )}
                </div>
                <span
                  className={`text-sm font-medium ${
                    status === "pending" ? "text-muted-foreground" : ""
                  }`}
                >
                  {step.label}
                </span>
              </div>
            );
          })}
        </div>

        {error && (
          <div className="flex items-start gap-2 p-3 bg-destructive/10 text-destructive rounded-lg">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <p className="text-sm" data-testid="text-processing-error">{error}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
