import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

interface AdsConfig {
  id: string;
  providerName: string;
  adCode: string;
  placement: string;
  enabled: boolean;
}

interface AdPlaceholderProps {
  onUpgrade?: () => void;
  placement?: "free_tier" | "shared_links" | "both";
}

export function AdPlaceholder({ onUpgrade, placement = "free_tier" }: AdPlaceholderProps) {
  const { data: ads } = useQuery<AdsConfig[]>({
    queryKey: ["/api/ads", placement],
  });

  const activeAd = ads?.find(ad => ad.enabled);

  return (
    <Card className="bg-muted/50 border-dashed" data-testid="ad-placeholder">
      <CardContent className="flex flex-col items-center justify-center py-8 text-center">
        {activeAd ? (
          <div 
            className="w-full min-h-[120px] flex items-center justify-center"
            dangerouslySetInnerHTML={{ __html: activeAd.adCode }}
          />
        ) : (
          <div className="w-full h-[120px] flex items-center justify-center bg-muted/30 rounded-lg mb-4">
            <div className="text-muted-foreground text-sm">
              Advertisement Space
            </div>
          </div>
        )}
        <div className="space-y-2 mt-4">
          <p className="text-sm text-muted-foreground">
            Upgrade to remove ads and unlock premium features
          </p>
          {onUpgrade && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onUpgrade}
              data-testid="button-upgrade-remove-ads"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Upgrade Now
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
