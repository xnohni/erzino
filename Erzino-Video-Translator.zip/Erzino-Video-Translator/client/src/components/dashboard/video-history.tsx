import { Play, Share2, MoreVertical, Clock, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Video } from "@shared/schema";

interface VideoHistoryProps {
  videos: Video[];
  onSelect: (video: Video) => void;
  onShare?: (video: Video) => void;
  isPaidUser?: boolean;
}

export function VideoHistory({
  videos,
  onSelect,
  onShare,
  isPaidUser = false,
}: VideoHistoryProps) {
  const formatDate = (date: Date | null) => {
    if (!date) return "Recently";
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(date));
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  if (!isPaidUser) {
    return (
      <Card data-testid="video-history">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Video History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 space-y-4">
            <div className="w-12 h-12 mx-auto rounded-full bg-muted flex items-center justify-center">
              <Clock className="w-6 h-6 text-muted-foreground" />
            </div>
            <div>
              <p className="font-medium">Video History Unavailable</p>
              <p className="text-sm text-muted-foreground">
                Upgrade to a paid plan to access your video history
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="video-history">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Video History
          {videos.length > 0 && (
            <Badge variant="secondary" className="ml-auto">
              {videos.length}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {videos.length === 0 ? (
          <div className="text-center py-8 px-6 space-y-4">
            <div className="w-12 h-12 mx-auto rounded-full bg-muted flex items-center justify-center">
              <Play className="w-6 h-6 text-muted-foreground" />
            </div>
            <div>
              <p className="font-medium">No Videos Yet</p>
              <p className="text-sm text-muted-foreground">
                Your translated videos will appear here
              </p>
            </div>
          </div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="space-y-1 p-2">
              {videos.map((video) => (
                <div
                  key={video.id}
                  className="flex items-center gap-3 p-3 rounded-lg hover-elevate cursor-pointer"
                  onClick={() => onSelect(video)}
                  data-testid={`video-history-item-${video.id}`}
                >
                  <div className="w-20 h-12 rounded bg-muted flex items-center justify-center shrink-0 overflow-hidden">
                    {video.thumbnailUrl ? (
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Play className="w-5 h-5 text-muted-foreground" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate text-sm">{video.title}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{formatDuration(video.duration)}</span>
                      <span>-</span>
                      <span className="capitalize">{video.platform}</span>
                    </div>
                  </div>

                  <Badge
                    variant={video.status === "completed" ? "default" : "secondary"}
                    className="shrink-0"
                  >
                    {video.status}
                  </Badge>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="shrink-0"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onSelect(video)}>
                        <Play className="w-4 h-4 mr-2" />
                        Watch
                      </DropdownMenuItem>
                      {onShare && (
                        <DropdownMenuItem onClick={() => onShare(video)}>
                          <Share2 className="w-4 h-4 mr-2" />
                          Share
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
