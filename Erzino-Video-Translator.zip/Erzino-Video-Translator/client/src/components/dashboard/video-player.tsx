import { useState, useRef, useEffect } from "react";
import {
  Play,
  Subtitles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import type { SmartSyncEntry } from "@shared/schema";

interface VideoPlayerProps {
  videoUrl?: string;
  subtitles?: SmartSyncEntry[];
  subtitleSettings?: {
    fontSize: number;
    fontColor: string;
    backgroundColor: string;
    fontFamily: string;
    position: string;
  };
  onTimeUpdate?: (time: number) => void;
  showControls?: boolean;
}

type Platform = "youtube" | "vimeo" | "dailymotion" | null;

function detectPlatform(url: string): Platform {
  if (url.includes("youtube.com") || url.includes("youtu.be")) {
    return "youtube";
  }
  if (url.includes("vimeo.com")) {
    return "vimeo";
  }
  if (url.includes("dailymotion.com") || url.includes("dai.ly")) {
    return "dailymotion";
  }
  return null;
}

function extractVideoId(url: string, platform: Platform): string | null {
  try {
    const urlObj = new URL(url);
    
    switch (platform) {
      case "youtube": {
        if (url.includes("youtu.be")) {
          return urlObj.pathname.slice(1).split("?")[0];
        }
        if (url.includes("/shorts/")) {
          const match = url.match(/\/shorts\/([a-zA-Z0-9_-]+)/);
          return match ? match[1] : null;
        }
        if (url.includes("/embed/")) {
          const match = url.match(/\/embed\/([a-zA-Z0-9_-]+)/);
          return match ? match[1] : null;
        }
        return urlObj.searchParams.get("v");
      }
      case "vimeo": {
        if (url.includes("player.vimeo.com/video/")) {
          const match = url.match(/player\.vimeo\.com\/video\/(\d+)/);
          return match ? match[1] : null;
        }
        if (url.includes("/channels/")) {
          const match = url.match(/\/channels\/[^/]+\/(\d+)/);
          return match ? match[1] : null;
        }
        if (url.includes("/groups/")) {
          const match = url.match(/\/groups\/[^/]+\/videos\/(\d+)/);
          return match ? match[1] : null;
        }
        const match = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
        return match ? match[1] : null;
      }
      case "dailymotion": {
        if (url.includes("dai.ly")) {
          return urlObj.pathname.slice(1).split("?")[0];
        }
        if (url.includes("/embed/video/")) {
          const match = url.match(/\/embed\/video\/([a-zA-Z0-9]+)/);
          return match ? match[1] : null;
        }
        const match = url.match(/video\/([a-zA-Z0-9]+)/);
        return match ? match[1] : null;
      }
      default:
        return null;
    }
  } catch {
    return null;
  }
}

function getEmbedUrl(videoId: string, platform: Platform): string | null {
  switch (platform) {
    case "youtube":
      return `https://www.youtube.com/embed/${videoId}?enablejsapi=1&origin=${window.location.origin}`;
    case "vimeo":
      return `https://player.vimeo.com/video/${videoId}?byline=0&portrait=0`;
    case "dailymotion":
      return `https://www.dailymotion.com/embed/video/${videoId}`;
    default:
      return null;
  }
}

export function VideoPlayer({
  videoUrl,
  subtitles = [],
  subtitleSettings = {
    fontSize: 18,
    fontColor: "#ffffff",
    backgroundColor: "rgba(0,0,0,0.7)",
    fontFamily: "Outfit",
    position: "bottom",
  },
  onTimeUpdate,
  showControls = true,
}: VideoPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [currentSubtitle, setCurrentSubtitle] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(0);

  const platform = videoUrl ? detectPlatform(videoUrl) : null;
  const videoId = videoUrl && platform ? extractVideoId(videoUrl, platform) : null;
  const embedUrl = videoId && platform ? getEmbedUrl(videoId, platform) : null;

  useEffect(() => {
    if (subtitles.length > 0 && showSubtitles) {
      const subtitle = subtitles.find(
        (s) => currentTime >= s.startTime && currentTime <= s.endTime
      );
      setCurrentSubtitle(subtitle?.text || null);
    } else {
      setCurrentSubtitle(null);
    }
  }, [currentTime, subtitles, showSubtitles]);

  useEffect(() => {
    if (!showSubtitles) return;
    
    const interval = setInterval(() => {
      setCurrentTime((prev) => {
        const newTime = prev + 0.5;
        onTimeUpdate?.(newTime);
        return newTime;
      });
    }, 500);
    
    return () => clearInterval(interval);
  }, [showSubtitles, onTimeUpdate]);

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-video bg-black rounded-lg overflow-hidden group"
      data-testid="video-player"
    >
      {!videoUrl || !embedUrl ? (
        <div className="absolute inset-0 bg-gradient-to-br from-muted/20 to-muted/40 flex items-center justify-center">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto rounded-full bg-muted/50 flex items-center justify-center">
              <Play className="w-10 h-10 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground">Paste a video URL to start</p>
            <p className="text-xs text-muted-foreground/60">
              Supports YouTube, Vimeo, and Dailymotion
            </p>
          </div>
        </div>
      ) : (
        <iframe
          src={embedUrl}
          className="absolute inset-0 w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          title="Video player"
          data-testid="video-embed"
        />
      )}

      {currentSubtitle && showSubtitles && embedUrl && (
        <div
          className={`absolute left-4 right-4 flex justify-center pointer-events-none ${
            subtitleSettings.position === "top" ? "top-8" : "bottom-8"
          }`}
        >
          <div
            className="px-4 py-2 rounded-lg max-w-[80%] text-center"
            style={{
              fontSize: `${subtitleSettings.fontSize}px`,
              color: subtitleSettings.fontColor,
              backgroundColor: subtitleSettings.backgroundColor,
              fontFamily: subtitleSettings.fontFamily,
            }}
            data-testid="subtitle-display"
          >
            {currentSubtitle}
          </div>
        </div>
      )}

      {showControls && embedUrl && (
        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowSubtitles(!showSubtitles)}
            className={`text-white bg-black/50 hover:bg-black/70 ${
              showSubtitles ? "ring-2 ring-primary" : ""
            }`}
            data-testid="button-subtitles-toggle"
          >
            <Subtitles className="w-5 h-5" />
          </Button>
        </div>
      )}
    </div>
  );
}
