import { useState } from "react";
import { Link2, Loader2, AlertCircle, CheckCircle, Play, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SUPPORTED_LANGUAGES } from "@shared/languages";
import { SiYoutube, SiVimeo, SiDailymotion } from "react-icons/si";

interface PreviousVideo {
  id: string;
  title: string;
  url: string;
  platform: string;
  duration: number;
}

interface VideoUrlInputProps {
  onSubmit: (url: string, language: string, estimatedMinutes?: number) => void;
  onWatchPrevious?: (videoId: string) => void;
  onBuyMore?: () => void;
  isProcessing?: boolean;
  remainingMinutes?: number;
}

type ValidationStatus = "idle" | "validating" | "valid" | "invalid";

export function VideoUrlInput({
  onSubmit,
  onWatchPrevious,
  onBuyMore,
  isProcessing = false,
  remainingMinutes = 0,
}: VideoUrlInputProps) {
  const [url, setUrl] = useState("");
  const [language, setLanguage] = useState("es");
  const [validationStatus, setValidationStatus] = useState<ValidationStatus>("idle");
  const [videoDuration, setVideoDuration] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showPreviousDialog, setShowPreviousDialog] = useState(false);
  const [showInsufficientDialog, setShowInsufficientDialog] = useState(false);
  const [requiredMinutes, setRequiredMinutes] = useState(0);
  const [previousVideo, setPreviousVideo] = useState<PreviousVideo | null>(null);
  const [previousLanguages, setPreviousLanguages] = useState<string[]>([]);
  const [durationUnknown, setDurationUnknown] = useState(false);
  const [manualMinutes, setManualMinutes] = useState<string>("");

  const detectPlatform = (videoUrl: string) => {
    if (videoUrl.includes("youtube.com") || videoUrl.includes("youtu.be")) {
      return "youtube";
    }
    if (videoUrl.includes("vimeo.com")) {
      return "vimeo";
    }
    if (videoUrl.includes("dailymotion.com") || videoUrl.includes("dai.ly")) {
      return "dailymotion";
    }
    return null;
  };

  const checkPreviousTranslation = async (videoUrl: string) => {
    try {
      const sessionId = localStorage.getItem("sessionId");
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (sessionId) {
        headers["Authorization"] = `Bearer ${sessionId}`;
      }
      
      const response = await fetch("/api/videos/check-previous", {
        method: "POST",
        headers,
        body: JSON.stringify({ url: videoUrl }),
        credentials: "include",
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.previouslyTranslated) {
          setPreviousVideo(data.video);
          setPreviousLanguages(data.languages);
          setShowPreviousDialog(true);
          return true;
        }
      }
      return false;
    } catch (err) {
      console.error("Error checking previous translation:", err);
      return false;
    }
  };

  const handleUrlChange = async (value: string) => {
    setUrl(value);
    setError(null);
    setVideoDuration(null);
    setManualMinutes("");
    setDurationUnknown(false);

    if (!value.trim()) {
      setValidationStatus("idle");
      return;
    }

    const platform = detectPlatform(value);
    if (!platform) {
      setValidationStatus("invalid");
      setError("Please enter a valid YouTube, Vimeo, or Dailymotion URL");
      return;
    }

    setValidationStatus("validating");

    try {
      const sessionId = localStorage.getItem("sessionId");
      const headers: Record<string, string> = {};
      if (sessionId) {
        headers["Authorization"] = `Bearer ${sessionId}`;
      }
      
      const response = await fetch(`/api/videos/duration?url=${encodeURIComponent(value)}`, {
        headers,
        credentials: "include",
      });
      
      if (response.ok) {
        const data = await response.json();
        setVideoDuration(data.durationSeconds);
        setDurationUnknown(!data.durationKnown);
        setValidationStatus("valid");
      } else {
        setValidationStatus("invalid");
        setError("Could not validate video URL");
      }
    } catch (err) {
      console.error("Error validating video:", err);
      setValidationStatus("invalid");
      setError("Could not validate video URL");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (validationStatus !== "valid") {
      setError("Please enter a valid video URL");
      return;
    }

    const effectiveMinutes = durationUnknown 
      ? (parseInt(manualMinutes) || 0)
      : Math.ceil((videoDuration || 0) / 60);
    
    if (durationUnknown && !manualMinutes) {
      setError("Please enter the estimated video duration in minutes");
      return;
    }
    
    if (effectiveMinutes > remainingMinutes) {
      setRequiredMinutes(effectiveMinutes);
      setShowInsufficientDialog(true);
      return;
    }

    const hasPrevious = await checkPreviousTranslation(url);
    if (!hasPrevious) {
      onSubmit(url, language, durationUnknown ? effectiveMinutes : undefined);
    }
  };

  const handleWatchPrevious = () => {
    if (previousVideo && onWatchPrevious) {
      onWatchPrevious(previousVideo.id);
    }
    setShowPreviousDialog(false);
  };

  const handleRetranslate = () => {
    setShowPreviousDialog(false);
    const effectiveMinutes = durationUnknown ? (parseInt(manualMinutes) || 0) : undefined;
    onSubmit(url, language, effectiveMinutes);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const platform = detectPlatform(url);

  return (
    <>
      <Card data-testid="video-url-input">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <Link2 className="w-5 h-5" />
            Video Translation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="video-url">Video URL</Label>
              <div className="relative">
                <Input
                  id="video-url"
                  type="url"
                  placeholder="Paste YouTube, Vimeo, or Dailymotion URL"
                  value={url}
                  onChange={(e) => handleUrlChange(e.target.value)}
                  className="pr-10"
                  disabled={isProcessing}
                  data-testid="input-video-url"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  {validationStatus === "validating" && (
                    <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                  )}
                  {validationStatus === "valid" && (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  )}
                  {validationStatus === "invalid" && (
                    <AlertCircle className="w-4 h-4 text-destructive" />
                  )}
                </div>
              </div>
            </div>

            {validationStatus === "valid" && (
              <div className="flex flex-col gap-3 p-3 bg-muted rounded-lg">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-2">
                    {platform === "youtube" && <SiYoutube className="w-5 h-5 text-red-500" />}
                    {platform === "vimeo" && <SiVimeo className="w-5 h-5 text-blue-500" />}
                    {platform === "dailymotion" && <SiDailymotion className="w-5 h-5 text-blue-600" />}
                    <span className="text-sm font-medium capitalize">{platform}</span>
                  </div>
                  {videoDuration && !durationUnknown ? (
                    <div className="text-sm text-muted-foreground">
                      Duration: {formatDuration(videoDuration)} ({Math.ceil(videoDuration / 60)} minutes)
                    </div>
                  ) : null}
                </div>
                {durationUnknown && (
                  <div className="space-y-2">
                    <p className="text-sm text-amber-600 dark:text-amber-500">
                      Duration unavailable. Please enter the video length manually:
                    </p>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min="1"
                        max="999"
                        placeholder="Minutes"
                        value={manualMinutes}
                        onChange={(e) => setManualMinutes(e.target.value)}
                        className="w-24"
                        data-testid="input-manual-minutes"
                      />
                      <span className="text-sm text-muted-foreground">minutes</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="target-language">Target Language</Label>
              <Select
                value={language}
                onValueChange={setLanguage}
                disabled={isProcessing}
              >
                <SelectTrigger id="target-language" data-testid="select-target-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 bg-destructive/10 text-destructive rounded-lg">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <p className="text-sm" data-testid="text-error">{error}</p>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <div className="text-sm text-muted-foreground">
                Minutes remaining: <span className="font-medium text-foreground">{remainingMinutes}</span>
              </div>
              <Button
                type="submit"
                disabled={isProcessing || validationStatus !== "valid"}
                data-testid="button-translate"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Processing...
                  </>
                ) : (
                  "Translate"
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Dialog open={showPreviousDialog} onOpenChange={setShowPreviousDialog}>
        <DialogContent data-testid="dialog-previous-translation">
          <DialogHeader>
            <DialogTitle>Video Already Translated</DialogTitle>
            <DialogDescription>
              This video has already been translated. Would you like to watch the existing translation or create a new one?
            </DialogDescription>
          </DialogHeader>
          
          {previousVideo && (
            <div className="py-4">
              <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                <div className="flex items-center gap-2">
                  {previousVideo.platform === "youtube" && <SiYoutube className="w-5 h-5 text-red-500" />}
                  {previousVideo.platform === "vimeo" && <SiVimeo className="w-5 h-5 text-blue-500" />}
                  {previousVideo.platform === "dailymotion" && <SiDailymotion className="w-5 h-5 text-blue-600" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{previousVideo.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {Math.ceil(previousVideo.duration / 60)} min | Languages: {previousLanguages.join(", ")}
                  </p>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={handleRetranslate}
              className="flex items-center gap-2"
              data-testid="button-retranslate"
            >
              <RefreshCw className="w-4 h-4" />
              Re-translate
            </Button>
            <Button
              onClick={handleWatchPrevious}
              className="flex items-center gap-2"
              data-testid="button-watch-previous"
            >
              <Play className="w-4 h-4" />
              Watch Previous
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showInsufficientDialog} onOpenChange={setShowInsufficientDialog}>
        <DialogContent data-testid="dialog-insufficient-minutes">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-destructive" />
              Insufficient Minutes
            </DialogTitle>
            <DialogDescription>
              This video requires <span className="font-semibold text-foreground">{requiredMinutes} minutes</span> to translate, 
              but you only have <span className="font-semibold text-foreground">{remainingMinutes} minutes</span> remaining.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="p-4 bg-muted rounded-lg text-center space-y-2">
              <p className="text-sm text-muted-foreground">You need at least</p>
              <p className="text-3xl font-bold gradient-text">
                {requiredMinutes - remainingMinutes} more minutes
              </p>
              <p className="text-sm text-muted-foreground">to translate this video</p>
            </div>
          </div>

          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => setShowInsufficientDialog(false)}
              data-testid="button-cancel-insufficient"
            >
              Cancel
            </Button>
            {onBuyMore && (
              <Button
                onClick={() => {
                  setShowInsufficientDialog(false);
                  onBuyMore();
                }}
                data-testid="button-buy-more-insufficient"
              >
                Buy More Minutes
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
