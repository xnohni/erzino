import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { DashboardSidebar } from "@/components/dashboard/dashboard-sidebar";
import { VideoPlayer } from "@/components/dashboard/video-player";
import { VideoUrlInput } from "@/components/dashboard/video-url-input";
import { CaptionStylingPanel } from "@/components/dashboard/caption-styling-panel";
import { VideoHistory } from "@/components/dashboard/video-history";
import { ProcessingStatus } from "@/components/dashboard/processing-status";
import { BuyMinutesModal } from "@/components/dashboard/buy-minutes-modal";
import { ShareVideoDialog } from "@/components/dashboard/share-video-dialog";
import { AdPlaceholder } from "@/components/dashboard/ad-placeholder";
import { DiscountBanner } from "@/components/dashboard/discount-banner";
import { NotificationsDropdown } from "@/components/dashboard/notifications-dropdown";
import { useOnboarding, OnboardingTooltips } from "@/components/dashboard/onboarding-tooltips";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Clock, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { UserTier, Video, SmartSyncEntry, Subtitle } from "@shared/schema";

type ProcessingStep = "extracting" | "transcribing" | "translating" | "syncing" | "completed" | "failed";

interface UserData {
  id: string;
  name: string;
  email: string;
  tier: UserTier;
  minutesRemaining: number;
  emailVerified: boolean;
  totalPurchases: number;
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { showOnboarding, completeOnboarding } = useOnboarding();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState<ProcessingStep>("extracting");
  const [processingProgress, setProcessingProgress] = useState(0);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [subtitles, setSubtitles] = useState<SmartSyncEntry[]>([]);
  const [isBuyModalOpen, setIsBuyModalOpen] = useState(false);
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [videoToShare, setVideoToShare] = useState<Video | null>(null);
  
  const [captionSettings, setCaptionSettings] = useState({
    fontSize: 18,
    fontColor: "#ffffff",
    backgroundColor: "rgba(0,0,0,0.7)",
    fontFamily: "Outfit",
    position: "bottom",
  });
  
  const [showTranslationExistsDialog, setShowTranslationExistsDialog] = useState(false);
  const [pendingTranslation, setPendingTranslation] = useState<{ url: string; language: string } | null>(null);
  const [existingSubtitle, setExistingSubtitle] = useState<any>(null);

  const sessionId = localStorage.getItem("sessionId");

  // Handle payment success/cancelled from Stripe redirect
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const payment = urlParams.get("payment");
    const minutes = urlParams.get("minutes");
    
    if (payment === "success" && minutes) {
      toast({
        title: "Payment Successful",
        description: `${minutes} minutes have been added to your account.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
      window.history.replaceState({}, "", "/dashboard");
    } else if (payment === "cancelled") {
      toast({
        title: "Payment Cancelled",
        description: "Your purchase was cancelled. No charges were made.",
        variant: "destructive",
      });
      window.history.replaceState({}, "", "/dashboard");
    }
  }, [toast]);

  const { data: sessionData, isLoading: sessionLoading, error: sessionError } = useQuery<{ user: UserData }>({
    queryKey: ["/api/auth/session"],
    enabled: !!sessionId,
    queryFn: async () => {
      const res = await fetch("/api/auth/session", {
        headers: { Authorization: `Bearer ${sessionId}` },
      });
      if (!res.ok) throw new Error("Session invalid");
      return res.json();
    },
    retry: false,
  });

  const user = sessionData?.user;

  const { data: videosData } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
    enabled: !!user,
    queryFn: async () => {
      const res = await fetch("/api/videos", {
        headers: { Authorization: `Bearer ${sessionId}` },
      });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: settingsData } = useQuery<typeof captionSettings>({
    queryKey: ["/api/subtitle-settings"],
    enabled: !!user,
    queryFn: async () => {
      const res = await fetch("/api/subtitle-settings", {
        headers: { Authorization: `Bearer ${sessionId}` },
      });
      if (!res.ok) return captionSettings;
      const data = await res.json();
      return data || captionSettings;
    },
  });

  useEffect(() => {
    if (settingsData) {
      setCaptionSettings(settingsData);
    }
  }, [settingsData]);

  useEffect(() => {
    if (!sessionId || sessionError) {
      setLocation("/");
    }
  }, [sessionId, sessionError, setLocation]);

  const processVideoMutation = useMutation({
    mutationFn: async ({ url, language, estimatedMinutes }: { url: string; language: string; estimatedMinutes?: number }) => {
      const res = await apiRequest("POST", "/api/videos/process", { 
        url, 
        targetLanguage: language,
        estimatedMinutes 
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
    },
  });

  const saveSettingsMutation = useMutation({
    mutationFn: async (settings: typeof captionSettings) => {
      const res = await apiRequest("POST", "/api/subtitle-settings", {
        ...settings,
        userId: user?.id,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subtitle-settings"] });
      toast({
        title: "Settings Saved",
        description: "Your caption styling preferences have been saved.",
      });
    },
  });

  const buyMinutesMutation = useMutation({
    mutationFn: async ({ minutes }: { minutes: number }) => {
      const res = await apiRequest("POST", "/api/users/buy-minutes", { minutes });
      return res.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
      toast({
        title: "Purchase Successful",
        description: `${variables.minutes} minutes have been added to your account.`,
      });
    },
  });

  const checkExistingTranslation = async (url: string, language: string): Promise<boolean> => {
    try {
      const videoIdMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|vimeo\.com\/|dailymotion\.com\/video\/)([a-zA-Z0-9_-]+)/);
      if (!videoIdMatch) return false;
      
      const res = await fetch(`/api/videos/check-translation?videoId=${videoIdMatch[1]}&language=${language}`, {
        headers: { Authorization: `Bearer ${sessionId}` },
      });
      if (!res.ok) return false;
      
      const data = await res.json();
      return data.exists;
    } catch {
      return false;
    }
  };

  const getVideoDuration = async (url: string): Promise<number | null> => {
    try {
      const res = await fetch(`/api/videos/duration?url=${encodeURIComponent(url)}`, {
        headers: { Authorization: `Bearer ${sessionId}` },
      });
      if (!res.ok) return null;
      
      const data = await res.json();
      return data.durationMinutes || null;
    } catch {
      return null;
    }
  };

  const handleTranslate = async (url: string, language: string, estimatedMinutes?: number) => {
    if (!user) return;
    
    const durationMinutes = estimatedMinutes ?? await getVideoDuration(url);
    if (durationMinutes !== null && durationMinutes > user.minutesRemaining) {
      toast({
        title: "Insufficient Minutes",
        description: `This video is ${Math.ceil(durationMinutes)} minutes long but you only have ${user.minutesRemaining} minutes remaining. Please purchase more minutes to continue.`,
        variant: "destructive",
      });
      setIsBuyModalOpen(true);
      return;
    }
    
    const exists = await checkExistingTranslation(url, language);
    if (exists) {
      setPendingTranslation({ url, language });
      setShowTranslationExistsDialog(true);
      return;
    }
    
    await performTranslation(url, language, estimatedMinutes);
  };

  const performTranslation = async (url: string, language: string, estimatedMinutes?: number) => {
    if (!user) return;
    
    setIsProcessing(true);
    setProcessingStep("extracting");
    setProcessingProgress(0);
    setSubtitles([]);

    const steps: ProcessingStep[] = ["extracting", "transcribing", "translating", "syncing"];
    
    for (let i = 0; i < steps.length; i++) {
      setProcessingStep(steps[i]);
      
      for (let j = 0; j <= 25; j++) {
        await new Promise((resolve) => setTimeout(resolve, 50));
        setProcessingProgress(i * 25 + j);
      }
    }

    try {
      const result = await processVideoMutation.mutateAsync({ url, language, estimatedMinutes });
      
      setProcessingStep("completed");
      setProcessingProgress(100);
      
      if (result.video) {
        setCurrentVideo(result.video);
      }
      
      if (result.subtitles) {
        try {
          const parsed = JSON.parse(result.subtitles.content);
          setSubtitles(parsed);
        } catch {
          setSubtitles([]);
        }
      }

      toast({
        title: "Translation Complete",
        description: "Your video has been translated successfully.",
      });
    } catch (error) {
      setProcessingStep("failed");
      toast({
        title: "Translation Failed",
        description: "There was an error processing your video.",
        variant: "destructive",
      });
    }

    setTimeout(() => {
      setIsProcessing(false);
    }, 1000);
  };

  const handleSelectVideo = async (video: Video) => {
    setCurrentVideo(video);
    
    try {
      const res = await fetch(`/api/subtitles/${video.id}`, {
        headers: { Authorization: `Bearer ${sessionId}` },
      });
      if (res.ok) {
        const subs: Subtitle[] = await res.json();
        if (subs.length > 0) {
          try {
            const parsed = JSON.parse(subs[0].content);
            setSubtitles(parsed);
          } catch {
            setSubtitles([]);
          }
        }
      }
    } catch {
      setSubtitles([]);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("sessionId");
    setLocation("/");
  };

  const handleBuyMore = () => {
    setIsBuyModalOpen(true);
  };

  const handlePurchase = (minutes: number, price: number) => {
    buyMinutesMutation.mutate({ minutes });
  };

  const handleSaveSettings = () => {
    saveSettingsMutation.mutate(captionSettings);
  };

  const handleDownloadSRT = () => {
    if (subtitles.length === 0) return;
    
    let srtContent = "";
    subtitles.forEach((sub, index) => {
      const startTime = formatSRTTime(sub.startTime);
      const endTime = formatSRTTime(sub.endTime);
      srtContent += `${index + 1}\n${startTime} --> ${endTime}\n${sub.text}\n\n`;
    });
    
    downloadFile(srtContent, "subtitles.srt", "text/plain");
    toast({
      title: "Download Started",
      description: "Your SRT file is being downloaded.",
    });
  };

  const handleDownloadVTT = () => {
    if (subtitles.length === 0) return;
    
    let vttContent = "WEBVTT\n\n";
    subtitles.forEach((sub, index) => {
      const startTime = formatVTTTime(sub.startTime);
      const endTime = formatVTTTime(sub.endTime);
      vttContent += `${index + 1}\n${startTime} --> ${endTime}\n${sub.text}\n\n`;
    });
    
    downloadFile(vttContent, "subtitles.vtt", "text/vtt");
    toast({
      title: "Download Started",
      description: "Your VTT file is being downloaded.",
    });
  };

  if (sessionLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const isPaidUser = user.tier !== "free";

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3.5rem",
  } as React.CSSProperties;

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex h-screen w-full bg-background">
        <DashboardSidebar
          user={user}
          onLogout={handleLogout}
          onBuyMore={handleBuyMore}
        />
        
        <SidebarInset className="flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 h-14 px-4 border-b glass sticky top-0 z-50">
            <div className="flex items-center gap-2">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <h1 className="text-lg font-semibold">Dashboard</h1>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-primary/10 border border-primary/20" data-testid="display-minutes-left">
                <Clock className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">
                  <span className="text-primary font-bold">{user.minutesRemaining}</span>
                  <span className="text-muted-foreground ml-1">min left</span>
                </span>
              </div>
              {user.minutesRemaining < 5 && (
                <Button 
                  size="sm" 
                  onClick={handleBuyMore}
                  data-testid="button-buy-more-header"
                >
                  Buy More
                </Button>
              )}
              <NotificationsDropdown />
            </div>
          </header>

          <main className="flex-1 overflow-auto p-4 lg:p-6">
            {isPaidUser && (
              <DiscountBanner tier={user.tier} totalPurchases={user.totalPurchases || 0} />
            )}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full mt-4">
              <div className="lg:col-span-2 space-y-6">
                <VideoPlayer
                  videoUrl={currentVideo?.url}
                  subtitles={subtitles}
                  subtitleSettings={captionSettings}
                />

                {isProcessing ? (
                  <ProcessingStatus
                    currentStep={processingStep}
                    progress={processingProgress}
                  />
                ) : (
                  <VideoUrlInput
                    onSubmit={handleTranslate}
                    onBuyMore={handleBuyMore}
                    isProcessing={isProcessing}
                    remainingMinutes={user.minutesRemaining}
                  />
                )}
              </div>

              <div className="space-y-6">
                {!isPaidUser && (
                  <AdPlaceholder onUpgrade={handleBuyMore} />
                )}
                
                <CaptionStylingPanel
                  settings={captionSettings}
                  onSettingsChange={setCaptionSettings}
                  onSave={handleSaveSettings}
                  onDownloadSRT={handleDownloadSRT}
                  onDownloadVTT={handleDownloadVTT}
                  isPaidUser={isPaidUser}
                />

                {isPaidUser && (
                  <VideoHistory
                    videos={videosData || []}
                    onSelect={handleSelectVideo}
                    onShare={(video) => {
                      setVideoToShare(video);
                      setIsShareDialogOpen(true);
                    }}
                    isPaidUser={isPaidUser}
                  />
                )}
              </div>
            </div>
          </main>
        </SidebarInset>
      </div>

      <BuyMinutesModal
        isOpen={isBuyModalOpen}
        onClose={() => setIsBuyModalOpen(false)}
        tier={user.tier}
        totalPurchases={user.totalPurchases || 0}
        onPurchase={handlePurchase}
      />
      
      {videoToShare && (
        <ShareVideoDialog
          open={isShareDialogOpen}
          onOpenChange={setIsShareDialogOpen}
          videoId={videoToShare.id}
          videoTitle={videoToShare.title}
        />
      )}

      <AlertDialog open={showTranslationExistsDialog} onOpenChange={setShowTranslationExistsDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              Translation Already Exists
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <p>
                This video has been previously translated into <span className="font-semibold">{pendingTranslation?.language || "the selected language"}</span>.
              </p>
              <p>
                Do you want to watch the previous translation or re-translate?
              </p>
              <p className="text-xs text-muted-foreground">
                Re-translating will deduct minutes from your account and create a new translation.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:flex-row gap-2">
            <AlertDialogCancel 
              className="flex-1"
              onClick={() => {
                setShowTranslationExistsDialog(false);
                if (pendingTranslation && videosData) {
                  const existingVideo = videosData.find(v => v.url === pendingTranslation.url);
                  if (existingVideo) {
                    handleSelectVideo(existingVideo);
                  }
                }
                setPendingTranslation(null);
              }}
              data-testid="button-watch-existing"
            >
              Watch
            </AlertDialogCancel>
            <AlertDialogAction 
              className="flex-1"
              onClick={() => {
                setShowTranslationExistsDialog(false);
                if (pendingTranslation) {
                  performTranslation(pendingTranslation.url, pendingTranslation.language);
                  setPendingTranslation(null);
                }
              }}
              data-testid="button-retranslate"
            >
              Re-Translate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {showOnboarding && (
        <OnboardingTooltips onComplete={completeOnboarding} />
      )}
    </SidebarProvider>
  );
}

function formatSRTTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")},${String(ms).padStart(3, "0")}`;
}

function formatVTTTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${String(ms).padStart(3, "0")}`;
}

function downloadFile(content: string, filename: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
