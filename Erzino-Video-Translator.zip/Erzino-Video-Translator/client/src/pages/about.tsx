import { Link } from "wouter";
import { ArrowLeft, Play, Zap, Globe, Users, Target, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeToggle } from "@/components/theme-toggle";

export default function AboutPage() {
  const values = [
    {
      icon: Globe,
      title: "Global Accessibility",
      description: "Making video content accessible to everyone, regardless of language barriers.",
    },
    {
      icon: Target,
      title: "Precision",
      description: "Our Smart Sync technology ensures perfect subtitle timing for natural viewing.",
    },
    {
      icon: Users,
      title: "Community",
      description: "Building a platform that serves content creators and viewers worldwide.",
    },
    {
      icon: Heart,
      title: "Quality",
      description: "Delivering professional-grade translations powered by advanced AI.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4 h-16">
            <Link href="/">
              <Button variant="ghost" size="sm" data-testid="button-back-home">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="relative w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg">
              <Play className="w-6 h-6 text-white fill-white ml-0.5" />
              <Zap className="absolute -top-1 -right-1 w-4 h-4 text-secondary" />
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-4">About Erzino</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We're on a mission to break language barriers in video content through AI-powered translation technology.
          </p>
        </div>

        <div className="space-y-12">
          <section>
            <h2 className="text-2xl font-semibold mb-4">Our Story</h2>
            <div className="prose dark:prose-invert max-w-none">
              <p className="text-muted-foreground">
                Erzino was born from a simple idea: everyone deserves access to video content in their native language. 
                We saw how language barriers were preventing millions of people from enjoying educational content, 
                entertainment, and important information shared through video platforms.
              </p>
              <p className="text-muted-foreground mt-4">
                Using cutting-edge AI technology, we developed Smart Sync - our proprietary subtitle synchronization 
                technology that ensures translations aren't just accurate, but perfectly timed with the original speech. 
                This creates a seamless viewing experience that feels natural and professional.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-6">What We Stand For</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {values.map((value) => (
                <Card key={value.title}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-lg">
                      <value.icon className="w-5 h-5 text-primary" />
                      {value.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground text-sm">{value.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Our Technology</h2>
            <div className="prose dark:prose-invert max-w-none">
              <p className="text-muted-foreground">
                Erzino leverages advanced AI models to provide accurate transcription and translation in over 
                200 languages. Our Smart Sync technology analyzes speech patterns, pauses, and timing to 
                ensure subtitles appear at exactly the right moment, making translated content feel natural 
                to viewers.
              </p>
              <p className="text-muted-foreground mt-4">
                We support major video platforms including YouTube, Vimeo, and Dailymotion, making it easy 
                to translate content from anywhere on the web. Whether you're a content creator looking to 
                reach a global audience or a viewer wanting to understand content in another language, 
                Erzino has you covered.
              </p>
            </div>
          </section>

          <section className="text-center pt-8 border-t border-border">
            <h2 className="text-2xl font-semibold mb-4">Ready to Get Started?</h2>
            <p className="text-muted-foreground mb-6">
              Join thousands of users who are already breaking language barriers with Erzino.
            </p>
            <Link href="/">
              <Button size="lg" data-testid="button-get-started">
                Start Translating
              </Button>
            </Link>
          </section>
        </div>
      </main>
    </div>
  );
}
