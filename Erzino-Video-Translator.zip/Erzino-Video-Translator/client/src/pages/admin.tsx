import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Users, Settings, Tag, DollarSign, ArrowLeft, Calendar, Megaphone, FileText, Check, Download, Trash } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import type { User, SettingsApiCosts, DiscountCode, FiscalYear, AdsConfig } from "@shared/schema";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [apiCostSettings, setApiCostSettings] = useState<SettingsApiCosts | null>(null);
  const [newDiscountCode, setNewDiscountCode] = useState({
    code: "",
    discountValue: 10,
    startDate: "",
    endDate: "",
  });
  const [newAdsConfig, setNewAdsConfig] = useState({
    providerName: "",
    adCode: "",
    placement: "free_tier",
    enabled: true,
  });

  const sessionId = localStorage.getItem("sessionId");

  const { data: currentUser, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/user"],
    enabled: !!sessionId,
  });

  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    enabled: !!currentUser?.isAdmin,
  });

  const { data: settings, isLoading: settingsLoading } = useQuery<SettingsApiCosts>({
    queryKey: ["/api/admin/settings"],
    enabled: !!currentUser?.isAdmin,
  });

  const { data: discountCodes, isLoading: codesLoading } = useQuery<DiscountCode[]>({
    queryKey: ["/api/admin/discount-codes"],
    enabled: !!currentUser?.isAdmin,
  });

  const { data: fiscalStats } = useQuery<{
    totalRevenue: number;
    totalMinutesSold: number;
    totalUsers: number;
    paidUsers: number;
  }>({
    queryKey: ["/api/admin/fiscal-stats"],
    enabled: !!currentUser?.isAdmin,
  });

  const { data: fiscalYears, isLoading: fiscalYearsLoading } = useQuery<FiscalYear[]>({
    queryKey: ["/api/admin/fiscal-years"],
    enabled: !!currentUser?.isAdmin,
  });

  const { data: adsConfigs, isLoading: adsConfigsLoading } = useQuery<AdsConfig[]>({
    queryKey: ["/api/admin/ads-config"],
    enabled: !!currentUser?.isAdmin,
  });

  useEffect(() => {
    if (settings) {
      setApiCostSettings(settings);
    }
  }, [settings]);

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: Partial<SettingsApiCosts>) => {
      const res = await apiRequest("PATCH", "/api/admin/settings", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
      toast({ title: "Settings updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update settings", variant: "destructive" });
    },
  });

  const updateUserTierMutation = useMutation({
    mutationFn: async ({ userId, tier }: { userId: string; tier: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/tier`, { tier });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "User tier updated" });
    },
    onError: () => {
      toast({ title: "Failed to update user tier", variant: "destructive" });
    },
  });

  const addMinutesMutation = useMutation({
    mutationFn: async ({ userId, minutes }: { userId: string; minutes: number }) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/add-minutes`, { minutes });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Minutes added successfully" });
    },
    onError: () => {
      toast({ title: "Failed to add minutes", variant: "destructive" });
    },
  });

  const createDiscountCodeMutation = useMutation({
    mutationFn: async (data: typeof newDiscountCode) => {
      const res = await apiRequest("POST", "/api/admin/discount-codes", {
        ...data,
        startDate: new Date(data.startDate).toISOString(),
        endDate: new Date(data.endDate).toISOString(),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/discount-codes"] });
      setNewDiscountCode({ code: "", discountValue: 10, startDate: "", endDate: "" });
      toast({ title: "Discount code created" });
    },
    onError: () => {
      toast({ title: "Failed to create discount code", variant: "destructive" });
    },
  });

  const deleteDiscountCodeMutation = useMutation({
    mutationFn: async (codeId: string) => {
      const res = await apiRequest("DELETE", `/api/admin/discount-codes/${codeId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/discount-codes"] });
      toast({ title: "Discount code deleted" });
    },
    onError: () => {
      toast({ title: "Failed to delete discount code", variant: "destructive" });
    },
  });

  const markFiscalYearPaidMutation = useMutation({
    mutationFn: async (yearId: string) => {
      const res = await apiRequest("POST", `/api/admin/fiscal-years/${yearId}/mark-paid`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fiscal-years"] });
      toast({ title: "Fiscal year marked as paid" });
    },
    onError: () => {
      toast({ title: "Failed to mark fiscal year as paid", variant: "destructive" });
    },
  });

  const createAdsConfigMutation = useMutation({
    mutationFn: async (data: typeof newAdsConfig) => {
      const res = await apiRequest("POST", "/api/admin/ads-config", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ads-config"] });
      setNewAdsConfig({ providerName: "", adCode: "", placement: "free_tier", enabled: true });
      toast({ title: "Ads configuration created" });
    },
    onError: () => {
      toast({ title: "Failed to create ads configuration", variant: "destructive" });
    },
  });

  const updateAdsConfigMutation = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<AdsConfig> & { id: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/ads-config/${id}`, updates);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ads-config"] });
      toast({ title: "Ads configuration updated" });
    },
    onError: () => {
      toast({ title: "Failed to update ads configuration", variant: "destructive" });
    },
  });

  const deleteAdsConfigMutation = useMutation({
    mutationFn: async (configId: string) => {
      const res = await apiRequest("DELETE", `/api/admin/ads-config/${configId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ads-config"] });
      toast({ title: "Ads configuration deleted" });
    },
    onError: () => {
      toast({ title: "Failed to delete ads configuration", variant: "destructive" });
    },
  });

  const suspendUserMutation = useMutation({
    mutationFn: async ({ userId, reason }: { userId: string; reason?: string }) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/suspend`, { reason });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "User suspended successfully" });
    },
    onError: () => {
      toast({ title: "Failed to suspend user", variant: "destructive" });
    },
  });

  const unsuspendUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/unsuspend`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "User unsuspended successfully" });
    },
    onError: () => {
      toast({ title: "Failed to unsuspend user", variant: "destructive" });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("DELETE", `/api/admin/users/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "User deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete user", variant: "destructive" });
    },
  });

  const sendNotificationMutation = useMutation({
    mutationFn: async ({ userId, title, message, type }: { userId: string; title: string; message: string; type: string }) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/notify`, { title, message, type });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Notification sent successfully" });
    },
    onError: () => {
      toast({ title: "Failed to send notification", variant: "destructive" });
    },
  });

  if (userLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!currentUser?.isAdmin) {
    return (
      <div className="flex h-screen flex-col items-center justify-center gap-4">
        <h1 className="text-2xl font-bold">Access Denied</h1>
        <p className="text-muted-foreground">You do not have permission to access this page.</p>
        <Button onClick={() => setLocation("/dashboard")} data-testid="button-back-dashboard">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage users, settings, and discount codes</p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => setLocation("/dashboard")}
            data-testid="button-back-to-dashboard"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card data-testid="card-total-revenue">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${((fiscalStats?.totalRevenue || 0) / 100).toFixed(2)}
              </div>
            </CardContent>
          </Card>
          <Card data-testid="card-minutes-sold">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Minutes Sold</CardTitle>
              <Tag className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{fiscalStats?.totalMinutesSold || 0}</div>
            </CardContent>
          </Card>
          <Card data-testid="card-total-users">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{fiscalStats?.totalUsers || 0}</div>
            </CardContent>
          </Card>
          <Card data-testid="card-paid-users">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Paid Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{fiscalStats?.paidUsers || 0}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList data-testid="admin-tabs" className="flex-wrap gap-1">
            <TabsTrigger value="users" data-testid="tab-users">
              <Users className="w-4 h-4 mr-2" />
              Users
            </TabsTrigger>
            <TabsTrigger value="settings" data-testid="tab-settings">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </TabsTrigger>
            <TabsTrigger value="discounts" data-testid="tab-discounts">
              <Tag className="w-4 h-4 mr-2" />
              Discounts
            </TabsTrigger>
            <TabsTrigger value="fiscal" data-testid="tab-fiscal">
              <Calendar className="w-4 h-4 mr-2" />
              Fiscal
            </TabsTrigger>
            <TabsTrigger value="ads" data-testid="tab-ads">
              <Megaphone className="w-4 h-4 mr-2" />
              Ads
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Email</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Tier</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Minutes</TableHead>
                        <TableHead>Purchases</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users?.map((user) => (
                        <TableRow key={user.id} data-testid={`row-user-${user.id}`} className={user.isSuspended ? "bg-destructive/10" : ""}>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.name}</TableCell>
                          <TableCell>
                            <Select
                              value={user.tier}
                              onValueChange={(value) =>
                                updateUserTierMutation.mutate({ userId: user.id, tier: value })
                              }
                              disabled={user.isAdmin || user.isSuspended}
                            >
                              <SelectTrigger className="w-28" data-testid={`select-tier-${user.id}`}>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="free">Free</SelectItem>
                                <SelectItem value="standard">Standard</SelectItem>
                                <SelectItem value="student">Student</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            {user.isAdmin ? (
                              <Badge className="bg-primary text-primary-foreground">Admin</Badge>
                            ) : user.isSuspended ? (
                              <Badge variant="destructive">Suspended</Badge>
                            ) : (
                              <Badge variant="outline">Active</Badge>
                            )}
                          </TableCell>
                          <TableCell>{user.minutesRemaining}</TableCell>
                          <TableCell>{user.totalPurchases}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1 flex-wrap">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  addMinutesMutation.mutate({ userId: user.id, minutes: 30 })
                                }
                                disabled={user.isAdmin}
                                data-testid={`button-add-minutes-${user.id}`}
                              >
                                +30 min
                              </Button>
                              {!user.isAdmin && (
                                <>
                                  {user.isSuspended ? (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => unsuspendUserMutation.mutate(user.id)}
                                      disabled={unsuspendUserMutation.isPending}
                                      data-testid={`button-unsuspend-${user.id}`}
                                    >
                                      Unsuspend
                                    </Button>
                                  ) : (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => suspendUserMutation.mutate({ userId: user.id, reason: "Suspended by admin" })}
                                      disabled={suspendUserMutation.isPending}
                                      data-testid={`button-suspend-${user.id}`}
                                    >
                                      Suspend
                                    </Button>
                                  )}
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (confirm(`Are you sure you want to delete user ${user.email}? This cannot be undone.`)) {
                                        deleteUserMutation.mutate(user.id);
                                      }
                                    }}
                                    disabled={deleteUserMutation.isPending}
                                    data-testid={`button-delete-user-${user.id}`}
                                  >
                                    <Trash className="w-3 h-3" />
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>API Cost Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {settingsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                ) : apiCostSettings ? (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="transcribeCost">GPT-4o Transcribe Cost ($/min)</Label>
                        <Input
                          id="transcribeCost"
                          type="number"
                          step="0.0001"
                          value={apiCostSettings.gpt4oTranscribeCost}
                          onChange={(e) =>
                            setApiCostSettings({
                              ...apiCostSettings,
                              gpt4oTranscribeCost: parseFloat(e.target.value),
                            })
                          }
                          data-testid="input-transcribe-cost"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="miniCost">GPT-4o Mini Cost ($/min)</Label>
                        <Input
                          id="miniCost"
                          type="number"
                          step="0.0001"
                          value={apiCostSettings.gpt4oMiniCost}
                          onChange={(e) =>
                            setApiCostSettings({
                              ...apiCostSettings,
                              gpt4oMiniCost: parseFloat(e.target.value),
                            })
                          }
                          data-testid="input-mini-cost"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="profitMargin">Profit Margin (%)</Label>
                        <Input
                          id="profitMargin"
                          type="number"
                          step="0.01"
                          value={apiCostSettings.profitMargin * 100}
                          onChange={(e) =>
                            setApiCostSettings({
                              ...apiCostSettings,
                              profitMargin: parseFloat(e.target.value) / 100,
                            })
                          }
                          data-testid="input-profit-margin"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="vatPercentage">VAT (%)</Label>
                        <Input
                          id="vatPercentage"
                          type="number"
                          step="0.01"
                          value={apiCostSettings.vatPercentage * 100}
                          onChange={(e) =>
                            setApiCostSettings({
                              ...apiCostSettings,
                              vatPercentage: parseFloat(e.target.value) / 100,
                            })
                          }
                          data-testid="input-vat"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="taxPercentage">Tax (%)</Label>
                        <Input
                          id="taxPercentage"
                          type="number"
                          step="0.01"
                          value={apiCostSettings.taxPercentage * 100}
                          onChange={(e) =>
                            setApiCostSettings({
                              ...apiCostSettings,
                              taxPercentage: parseFloat(e.target.value) / 100,
                            })
                          }
                          data-testid="input-tax"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="studentDiscount">Student Discount (%)</Label>
                        <Input
                          id="studentDiscount"
                          type="number"
                          step="0.01"
                          value={apiCostSettings.studentDiscount * 100}
                          onChange={(e) =>
                            setApiCostSettings({
                              ...apiCostSettings,
                              studentDiscount: parseFloat(e.target.value) / 100,
                            })
                          }
                          data-testid="input-student-discount"
                        />
                      </div>
                    </div>
                    <Button
                      onClick={() => updateSettingsMutation.mutate(apiCostSettings)}
                      disabled={updateSettingsMutation.isPending}
                      data-testid="button-save-settings"
                    >
                      {updateSettingsMutation.isPending ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : null}
                      Save Settings
                    </Button>
                  </>
                ) : null}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="discounts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Create Discount Code</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="code">Code</Label>
                    <Input
                      id="code"
                      value={newDiscountCode.code}
                      onChange={(e) =>
                        setNewDiscountCode({ ...newDiscountCode, code: e.target.value.toUpperCase() })
                      }
                      placeholder="SUMMER20"
                      data-testid="input-discount-code"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discountValue">Discount (%)</Label>
                    <Input
                      id="discountValue"
                      type="number"
                      value={newDiscountCode.discountValue}
                      onChange={(e) =>
                        setNewDiscountCode({ ...newDiscountCode, discountValue: parseInt(e.target.value) })
                      }
                      data-testid="input-discount-value"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={newDiscountCode.startDate}
                      onChange={(e) =>
                        setNewDiscountCode({ ...newDiscountCode, startDate: e.target.value })
                      }
                      data-testid="input-start-date"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={newDiscountCode.endDate}
                      onChange={(e) =>
                        setNewDiscountCode({ ...newDiscountCode, endDate: e.target.value })
                      }
                      data-testid="input-end-date"
                    />
                  </div>
                </div>
                <Button
                  onClick={() => createDiscountCodeMutation.mutate(newDiscountCode)}
                  disabled={
                    createDiscountCodeMutation.isPending ||
                    !newDiscountCode.code ||
                    !newDiscountCode.startDate ||
                    !newDiscountCode.endDate
                  }
                  data-testid="button-create-code"
                >
                  {createDiscountCodeMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : null}
                  Create Code
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Active Discount Codes</CardTitle>
              </CardHeader>
              <CardContent>
                {codesLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Discount</TableHead>
                        <TableHead>Valid From</TableHead>
                        <TableHead>Valid Until</TableHead>
                        <TableHead>Usage</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {discountCodes?.map((code) => (
                        <TableRow key={code.id} data-testid={`row-code-${code.id}`}>
                          <TableCell>
                            <Badge variant="outline">{code.code}</Badge>
                          </TableCell>
                          <TableCell>{code.discountValue}%</TableCell>
                          <TableCell>
                            {new Date(code.startDate).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            {new Date(code.endDate).toLocaleDateString()}
                          </TableCell>
                          <TableCell>{code.usageCount}</TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteDiscountCodeMutation.mutate(code.id)}
                              data-testid={`button-delete-code-${code.id}`}
                            >
                              Delete
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                      {!discountCodes?.length && (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground">
                            No discount codes yet
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="fiscal" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Fiscal Year Dashboard - Tax & VAT Tracking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Track yearly tax (10%) and VAT (18% when total payments exceed 30,000). Each fiscal year starts from the first payment date.
                </p>
                {fiscalYearsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                ) : fiscalYears && fiscalYears.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Year</TableHead>
                        <TableHead>Start Date</TableHead>
                        <TableHead>End Date</TableHead>
                        <TableHead>Total Payments</TableHead>
                        <TableHead>Total Tax (10%)</TableHead>
                        <TableHead>Total VAT (18%)</TableHead>
                        <TableHead>Report</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {fiscalYears.map((year) => (
                        <TableRow key={year.id} data-testid={`row-fiscal-${year.id}`}>
                          <TableCell className="font-medium">Year {year.yearNumber}</TableCell>
                          <TableCell>
                            {new Date(year.startDate).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            {new Date(year.endDate).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="font-medium">
                            {year.totalPayments.toFixed(2)}
                          </TableCell>
                          <TableCell>
                            {year.totalTax.toFixed(2)}
                          </TableCell>
                          <TableCell>
                            {year.vatActive ? (
                              <span className="text-amber-500">{year.totalVat.toFixed(2)}</span>
                            ) : (
                              <span className="text-muted-foreground">N/A (below 30k)</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                window.open(`/api/admin/fiscal-years/${year.id}/pdf`, '_blank');
                              }}
                              data-testid={`button-download-report-${year.id}`}
                            >
                              <Download className="w-4 h-4 mr-1" />
                              PDF
                            </Button>
                          </TableCell>
                          <TableCell>
                            {year.isPaid ? (
                              <Badge className="bg-green-500 text-white">
                                <Check className="w-3 h-3 mr-1" />
                                Paid
                              </Badge>
                            ) : (
                              <Button
                                size="sm"
                                onClick={() => markFiscalYearPaidMutation.mutate(year.id)}
                                disabled={markFiscalYearPaidMutation.isPending}
                                data-testid={`button-mark-paid-${year.id}`}
                              >
                                Mark as Paid
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    No fiscal years yet. The first fiscal year will be created when the first payment is received.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ads" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Create Ads Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="providerName">Provider Name</Label>
                    <Input
                      id="providerName"
                      value={newAdsConfig.providerName}
                      onChange={(e) =>
                        setNewAdsConfig({ ...newAdsConfig, providerName: e.target.value })
                      }
                      placeholder="e.g., Google AdSense"
                      data-testid="input-ads-provider"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="placement">Placement</Label>
                    <Select
                      value={newAdsConfig.placement}
                      onValueChange={(value) =>
                        setNewAdsConfig({ ...newAdsConfig, placement: value })
                      }
                    >
                      <SelectTrigger data-testid="select-ads-placement">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="free_tier">Free Tier Only</SelectItem>
                        <SelectItem value="shared_links">Shared Links Only</SelectItem>
                        <SelectItem value="both">Both</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="adCode">Ad Code (HTML/JS)</Label>
                  <Textarea
                    id="adCode"
                    value={newAdsConfig.adCode}
                    onChange={(e) =>
                      setNewAdsConfig({ ...newAdsConfig, adCode: e.target.value })
                    }
                    placeholder="Paste your ad embed code here..."
                    rows={4}
                    data-testid="input-ads-code"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="enabled"
                    checked={newAdsConfig.enabled}
                    onCheckedChange={(checked) =>
                      setNewAdsConfig({ ...newAdsConfig, enabled: checked })
                    }
                    data-testid="switch-ads-enabled"
                  />
                  <Label htmlFor="enabled">Enabled</Label>
                </div>
                <Button
                  onClick={() => createAdsConfigMutation.mutate(newAdsConfig)}
                  disabled={
                    createAdsConfigMutation.isPending ||
                    !newAdsConfig.providerName ||
                    !newAdsConfig.adCode
                  }
                  data-testid="button-create-ads"
                >
                  {createAdsConfigMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : null}
                  Create Ads Configuration
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Active Ads Configurations</CardTitle>
              </CardHeader>
              <CardContent>
                {adsConfigsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Provider</TableHead>
                        <TableHead>Placement</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {adsConfigs?.map((config) => (
                        <TableRow key={config.id} data-testid={`row-ads-${config.id}`}>
                          <TableCell className="font-medium">{config.providerName}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {config.placement === "free_tier" ? "Free Tier" :
                               config.placement === "shared_links" ? "Shared Links" : "Both"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Switch
                              checked={config.enabled}
                              onCheckedChange={(checked) =>
                                updateAdsConfigMutation.mutate({ id: config.id, enabled: checked })
                              }
                              data-testid={`switch-ads-status-${config.id}`}
                            />
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteAdsConfigMutation.mutate(config.id)}
                              data-testid={`button-delete-ads-${config.id}`}
                            >
                              Delete
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                      {!adsConfigs?.length && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground">
                            No ads configurations yet
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
