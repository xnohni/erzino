import { useState } from "react";
import { useLocation } from "wouter";
import { Navigation } from "@/components/navigation";
import { HeroSection } from "@/components/landing/hero-section";
import { FeaturesSection } from "@/components/landing/features-section";
import { PricingSection } from "@/components/landing/pricing-section";
import { HowItWorksSection } from "@/components/landing/how-it-works-section";
import { Footer } from "@/components/landing/footer";
import { AuthModal } from "@/components/auth/auth-modal";
import type { UserTier } from "@shared/schema";

export default function Landing() {
  const [, setLocation] = useLocation();
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authTab, setAuthTab] = useState<"login" | "signup">("signup");
  const [selectedTier, setSelectedTier] = useState<UserTier>("free");

  const handleLoginClick = () => {
    setAuthTab("login");
    setIsAuthOpen(true);
  };

  const handleSignupClick = () => {
    setAuthTab("signup");
    setSelectedTier("free");
    setIsAuthOpen(true);
  };

  const handleGetStarted = () => {
    setAuthTab("signup");
    setSelectedTier("free");
    setIsAuthOpen(true);
  };

  const handleSelectTier = (tier: UserTier) => {
    setSelectedTier(tier);
    setAuthTab("signup");
    setIsAuthOpen(true);
  };

  const handleAuthSuccess = () => {
    setIsAuthOpen(false);
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation
        onLoginClick={handleLoginClick}
        onSignupClick={handleSignupClick}
      />
      
      <main>
        <HeroSection onGetStarted={handleGetStarted} />
        <FeaturesSection />
        <HowItWorksSection />
        <PricingSection onSelectTier={handleSelectTier} />
      </main>

      <Footer />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        defaultTab={authTab}
        selectedTier={selectedTier}
        onSuccess={handleAuthSuccess}
      />
    </div>
  );
}
