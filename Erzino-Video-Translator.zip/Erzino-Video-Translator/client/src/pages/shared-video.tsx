import { useState, useEffect, useMemo } from "react";
import { useParams } from "wouter";
import { Lock, Loader2, AlertTriangle, Play, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { VideoPlayer } from "@/components/dashboard/video-player";
import { SiYoutube, SiVimeo, SiDailymotion } from "react-icons/si";
import type { SmartSyncEntry } from "@shared/schema";

function SharedPageAd() {
  return (
    <Card className="border-dashed" data-testid="shared-page-ad">
      <CardContent className="flex flex-col items-center justify-center py-6 gap-3">
        <div className="text-xs text-muted-foreground uppercase tracking-wide">Advertisement</div>
        <div className="w-full h-24 bg-muted/50 rounded-md flex items-center justify-center">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Ad Space</p>
          </div>
        </div>
        <div className="text-center mt-2">
          <p className="text-sm text-muted-foreground">
            Want ad-free translations with full features?
          </p>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-primary"
            onClick={() => window.location.href = "/"}
            data-testid="button-shared-upgrade"
          >
            <Sparkles className="w-3 h-3 mr-1" />
            Sign up for Erzino
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

interface Video {
  id: string;
  title: string;
  url: string;
  platform: string;
  duration: number;
}

interface Subtitle {
  id: string;
  videoId: string;
  language: string;
  content: string;
}

export default function SharedVideoPage() {
  const { shareCode } = useParams<{ shareCode: string }>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isPasswordProtected, setIsPasswordProtected] = useState(false);
  const [video, setVideo] = useState<Video | null>(null);
  const [subtitles, setSubtitles] = useState<Subtitle[]>([]);
  const [password, setPassword] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState("");
  
  // Parse the subtitle content to get SmartSyncEntry array
  const parsedSubtitles = useMemo((): SmartSyncEntry[] => {
    const selected = subtitles.find(s => s.language === selectedLanguage);
    if (!selected) return [];
    try {
      return JSON.parse(selected.content) as SmartSyncEntry[];
    } catch {
      return [];
    }
  }, [subtitles, selectedLanguage]);

  useEffect(() => {
    const fetchSharedVideo = async () => {
      try {
        const response = await fetch(`/api/shared/${shareCode}`);
        
        if (!response.ok) {
          if (response.status === 404) {
            setError("This shared link doesn't exist or has been removed.");
          } else if (response.status === 410) {
            setError("This shared link has expired.");
          } else {
            setError("Failed to load shared video.");
          }
          setLoading(false);
          return;
        }
        
        const data = await response.json();
        setIsPasswordProtected(data.isPasswordProtected);
        
        if (data.isPasswordProtected) {
          // Only metadata available
          if (data.video) {
            setVideo({ ...data.video, id: "", url: "" } as Video);
          }
        } else {
          setVideo(data.video);
          setSubtitles(data.subtitles || []);
          if (data.subtitles?.length > 0) {
            setSelectedLanguage(data.subtitles[0].language);
          }
        }
        
        setLoading(false);
      } catch (err) {
        console.error("Error fetching shared video:", err);
        setError("Failed to load shared video.");
        setLoading(false);
      }
    };

    if (shareCode) {
      fetchSharedVideo();
    }
  }, [shareCode]);

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifying(true);
    setPasswordError(null);
    
    try {
      const response = await fetch(`/api/shared/${shareCode}/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      
      if (!response.ok) {
        if (response.status === 403) {
          setPasswordError("Incorrect password. Please try again.");
        } else {
          setPasswordError("Failed to verify password.");
        }
        setVerifying(false);
        return;
      }
      
      const data = await response.json();
      setVideo(data.video);
      setSubtitles(data.subtitles || []);
      setIsPasswordProtected(false);
      if (data.subtitles?.length > 0) {
        setSelectedLanguage(data.subtitles[0].language);
      }
      setVerifying(false);
    } catch (err) {
      console.error("Error verifying password:", err);
      setPasswordError("Failed to verify password.");
      setVerifying(false);
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "youtube":
        return <SiYoutube className="w-5 h-5 text-red-500" />;
      case "vimeo":
        return <SiVimeo className="w-5 h-5 text-blue-500" />;
      case "dailymotion":
        return <SiDailymotion className="w-5 h-5 text-blue-600" />;
      default:
        return <Play className="w-5 h-5" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading shared video...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="flex flex-col items-center gap-4 pt-6">
            <AlertTriangle className="w-12 h-12 text-destructive" />
            <p className="text-center text-muted-foreground">{error}</p>
            <Button variant="outline" onClick={() => window.location.href = "/"}>
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isPasswordProtected) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="mx-auto mb-2 w-12 h-12 rounded-full bg-muted flex items-center justify-center">
              <Lock className="w-6 h-6" />
            </div>
            <CardTitle>Password Protected</CardTitle>
            <CardDescription>
              {video?.title && (
                <span className="block mt-2 font-medium text-foreground">{video.title}</span>
              )}
              Enter the password to view this shared video.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <Input
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={verifying}
                data-testid="input-shared-password"
              />
              {passwordError && (
                <p className="text-sm text-destructive">{passwordError}</p>
              )}
              <Button 
                type="submit" 
                className="w-full" 
                disabled={!password || verifying}
                data-testid="button-verify-password"
              >
                {verifying ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Verifying...
                  </>
                ) : (
                  "Unlock Video"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="flex flex-col items-center gap-4 pt-6">
            <AlertTriangle className="w-12 h-12 text-muted-foreground" />
            <p className="text-center text-muted-foreground">Video not found.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            {getPlatformIcon(video.platform)}
            <h1 className="text-xl font-semibold">{video.title}</h1>
          </div>
          <p className="text-sm text-muted-foreground">
            Shared video with translated subtitles
          </p>
        </div>

        {subtitles.length > 1 && (
          <div className="mb-4 flex items-center gap-3">
            <span className="text-sm text-muted-foreground">Language:</span>
            <div className="flex flex-wrap gap-2">
              {subtitles.map((sub) => (
                <Button
                  key={sub.language}
                  variant={selectedLanguage === sub.language ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedLanguage(sub.language)}
                  data-testid={`button-language-${sub.language}`}
                >
                  {sub.language.toUpperCase()}
                </Button>
              ))}
            </div>
          </div>
        )}

        <Card>
          <CardContent className="p-0">
            <VideoPlayer
              videoUrl={video.url}
              subtitles={parsedSubtitles}
            />
          </CardContent>
        </Card>

        <div className="mt-6">
          <SharedPageAd />
        </div>

        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            Powered by <span className="font-semibold text-primary">Erzino</span>
          </p>
        </div>
      </div>
    </div>
  );
}
